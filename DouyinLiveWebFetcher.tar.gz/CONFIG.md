# 配置说明

配置文件：`config.json`

完整示例：

```json
{
  "log_level": "INFO",
  "output": {
    "chat": true,
    "gift": true,
    "like": true,
    "member": true,
    "social": true,
    "rank": false,
    "stats": true,
    "fansclub": true,
    "emoji": true,
    "file_format": "json",
    "file_dir": "data"
  },
  "network": {
    "http_timeout": 15,
    "ws_connect_timeout": 30,
    "silence_timeout": 60,
    "heartbeat_interval": 10,
    "rcvbuf_kb": 256,
    "proxy": null
  },
  "max_reconnects": 0,
  "reconnect_base_delay": 2,
  "reconnect_max_delay": 120,
  "stats_interval": 60
}
```

---

## 全局配置

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `log_enabled` | bool | true | 是否输出日志，`false` 完全静默（数据文件照常写入） |
| `log_level` | string | `"INFO"` | 日志级别：`DEBUG` / `INFO` / `WARNING` / `ERROR` |

---

## 消息开关 (`output`)

控制哪些消息类型输出到日志和数据文件。

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `chat` | bool | true | 聊天消息（用户文字弹幕） |
| `gift` | bool | true | 礼物消息（用户赠送礼物） |
| `like` | bool | true | 点赞消息（用户点赞） |
| `member` | bool | true | 进场消息（用户进入直播间） |
| `social` | bool | true | 关注/分享消息 |
| `rank` | bool | false | 排行榜消息（积分排行榜） |
| `stats` | bool | true | 统计消息（在线人数等） |
| `fansclub` | bool | true | 粉丝团消息（加入/升级） |
| `emoji` | bool | true | 表情消息（表情包） |

### 数据文件输出

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `file_format` | string | `"none"` | 输出格式：`none` / `csv` / `json` (JSONL) / `both` |
| `file_dir` | string | `"data"` | 输出目录（相对于脚本目录） |

---

## 网络配置 (`network`)

适配弱网环境，所有超时单位为秒。

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `http_timeout` | int | 15 | HTTP 请求超时，超时后自动 ×1.5（封顶 60s），最多重试 3 次 |
| `ws_connect_timeout` | int | 30 | WebSocket 底层 socket 超时（连接 + 读写） |
| `silence_timeout` | int | 60 | 看门狗静默阈值，超过此时间无消息则判定断连并重连 |
| `heartbeat_interval` | int | 10 | 业务层心跳间隔（发送 hb 包维持连接） |
| `rcvbuf_kb` | int | 256 | WebSocket 接收缓冲区大小（KB），高流量直播间建议 512 |
| `proxy` | dict | null | 代理设置，格式见下方 |

### 代理配置

```json
"proxy": {
  "http": "http://127.0.0.1:8080",
  "https": "socks5://127.0.0.1:1080"
}
```

不需要代理时设为 `null`。

### 弱网推荐配置

2G/3G 或高延迟网络：

```json
{
  "network": {
    "http_timeout": 30,
    "ws_connect_timeout": 60,
    "silence_timeout": 180,
    "heartbeat_interval": 20,
    "rcvbuf_kb": 512
  }
}
```

---

## 重连配置

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `max_reconnects` | int | 0 | 最大重连次数，`0` = 无限重连 |
| `reconnect_base_delay` | float | 2 | 重连基础延迟（秒），指数退避：2s → 4s → 8s → ... |
| `reconnect_max_delay` | float | 120 | 最大重连延迟（秒），退避封顶 |

退避公式：`min(base_delay × 2^(n-1), max_delay) + random(0, 2)`

---

## 统计配置

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `stats_interval` | int | 60 | 吞吐量统计打印间隔（秒） |

统计输出示例：

```
[吞吐统计] 总计:3420 | 57.0msg/s | [chat:1200, member:800, roomstats:600, like:400, roomuserseq:300]
```

---

## HTTP 超时增长机制

当 HTTP 请求超时时，下次超时自动加大：

```
第 1 次: http_timeout (默认 15s)
第 2 次: 15 × 1.5 = 22s
第 3 次: 22 × 1.5 = 33s
         封顶 60s
```

最多重试 3 次（ConnectionError 和 Timeout 各计一次）。

---

## 看门狗机制

每 `silence_timeout / 3`（约 5~20s）检查一次 `_last_msg_time`：

- 正常：消息持续到达，`_last_msg_time` 不断更新
- 异常：超过 `silence_timeout` 无消息 → 关闭 WebSocket → 触发重连

适用场景：WiFi 切换、网络闪断、服务端静默断开（TCP 未正常关闭）。
