# 抖音直播间弹幕数据抓取（高性能弱网兼容版）

## 功能说明

实时抓取抖音直播间弹幕数据，支持 13 种消息类型：

| 消息类型 | 说明 | 日志标识 |
|---------|------|----------|
| **聊天消息** | 用户文字弹幕 | `聊天消息` |
| **进场消息** | 用户进入直播间 | `进场消息` |
| **点赞消息** | 用户点赞 | `点赞消息` |
| **关注/分享** | 关注主播或分享直播间 | `关注/分享消息` |
| **礼物消息** | 用户赠送礼物 | `礼物消息` |
| **粉丝团消息** | 加入/升级粉丝团 | `粉丝团消息` |
| **表情消息** | 用户发送表情包 | `表情消息` |
| **统计消息** | 实时在线人数等 | `统计消息` |
| **直播间统计** | 累计观看等 | `直播间统计信息` |
| **排行榜** | 积分排行榜 | `排行榜消息` |
| **直播间状态** | 开始/暂停/结束 | `直播间状态` |
| **直播间信息** | 置顶公告等 | `直播间信息` |
| **流配置** | 直播流适配 | `流配置消息` |

## 环境要求

- Python 3.7+
- Node.js（用于执行 JavaScript 签名脚本）

## 安装依赖

```bash
pip install -r requirements.txt
```

依赖包：

| 包名 | 版本 | 用途 |
|------|------|------|
| `requests` | ≥2.33.1 | HTTP 请求 |
| `websocket-client` | ≥1.9.0 | WebSocket 连接 |
| `PyExecJS` | ≥1.5.1 | 执行 JS 签名脚本 |
| `protobuf` | ≥7.34.1 | Protobuf 序列化 |
| `betterproto` | ≥1.2.5 | Protobuf 反序列化 |

## 快速开始

```bash
# 默认直播间
python3 main.py
```

### 修改直播间 ID

编辑 `main.py`，修改 `live_id` 变量：

```python
live_id = '536863152858'  # 替换为目标直播间 ID
```

## 配置说明

编辑 `config.json`，详见 [CONFIG.md](CONFIG.md)。

### 示例配置

```json
{
  "log_enabled": true,
  "log_level": "INFO",
  "output": {
    "chat": true,
    "gift": true,
    "like": true,
    "member": true,
    "social": true,
    "rank": false,
    "stats": true,
    "fansclub": true,
    "emoji": true,
    "file_format": "json",
    "file_dir": "data"
  },
  "network": {
    "http_timeout": 15,
    "ws_connect_timeout": 30,
    "silence_timeout": 60,
    "heartbeat_interval": 10,
    "rcvbuf_kb": 256,
    "proxy": null
  },
  "max_reconnects": 0,
  "reconnect_base_delay": 2,
  "reconnect_max_delay": 120,
  "stats_interval": 60
}
```

## 数据输出

支持三种输出模式（`output.file_format`）：

| 值 | 说明 |
|----|------|
| `none` | 仅输出到日志（默认） |
| `csv` | 按消息类型分 CSV 文件 |
| `json` | JSONL 格式，所有消息写入一个文件 |
| `both` | CSV + JSONL 同时输出 |

输出目录由 `output.file_dir` 指定（默认 `data/`）。

### JSONL 示例

```json
{"type": "chat", "ts": 1775954555.948, "data": {"time": "08:36:55", "user_id": "97992671880", "user_name": "幸运星陈", "content": "让我看看哪个美女好看？", "grade": "[等级6]", "fans_club": "[粉丝团 Lv1]"}}
{"type": "gift", "ts": 1775954558.123, "data": {"time": "08:36:58", "user_id": "12345", "user_name": "用户A", "gift_name": "玫瑰", "gift_count": 1, "diamond_total": 10, "grade": "[等级5]", "fans_club": ""}}
```

### CSV 文件

按消息类型分文件，UTF-8 BOM 编码，可直接用 Excel 打开：

```
data/
├── 536863152858_chat_20260412_083652.csv
├── 536863152858_gift_20260412_083652.csv
├── 536863152858_like_20260412_083652.csv
├── 536863152858_member_20260412_083652.csv
└── ...
```

## 程序运行机制

### 1. 获取 ttwid

访问 `https://live.douyin.com/` 获取 `ttwid` cookie，用于 WebSocket 鉴权。

### 2. 获取 roomId

访问 `https://live.douyin.com/{live_id}` 解析页面，三重正则提取真实 `roomId`。

### 3. WebSocket 连接

- 生成签名（`sign.js`）
- 建立 WebSocket 连接
- 启动心跳、看门狗、统计三个守护线程

### 4. 消息处理流程

```
WebSocket 二进制数据
    ↓
PushFrame 解析（帧头）
    ↓
gzip 解压（损坏则跳过，不崩溃）
    ↓
Response 解析（响应头）
    ↓
遍历 messages_list
    ↓
根据 method 字段分发到对应解析函数
    ↓
protobuf 反序列化
    ↓
日志输出 + 数据记录（批量写入）
```

### 5. 签名算法

#### WebSocket 签名（sign.js）

对 WebSocket URL 参数拼接后 MD5，再调用 JS 函数生成签名字符串。



## 架构设计

### 线程模型

| 线程名 | 职责 | 生命周期 |
|--------|------|----------|
| `MainThread` | 运行 `run_forever()`，阻塞接收 WS 消息 | 主线程 |
| `heartbeat` | 每 10s 发送业务层心跳包 | daemon，stop() 退出 |
| `watchdog` | 每 5s 检查是否静默断连 | daemon，stop() 退出 |
| `stats` | 每 60s 打印吞吐量统计 | daemon，stop() 退出 |
| `log-drain` | 每 0.5s drain 日志队列写文件/控制台 | daemon，进程退出 |
| `recorder-flush` | 每 2s 批量写 JSONL/CSV | daemon，stop() 退出 |

### 数据流

```
WS 回调 → logger.info() → _QueueHandler (deque) → log-drain → 文件/控制台
         → recorder.record() → DataRecorder (deque) → recorder-flush → JSONL/CSV
```

### 关键优化

| 优化项 | 说明 |
|--------|------|
| 反风控 | 动态 UA、user_unique_id、时间戳，每次运行随机 |
| JS 编译缓存 | sign.js 只编译一次，按文件 mtime 判断更新 |
| 非阻塞日志 | logger.emit() 只入队，后台线程批量写出 |
| 批量数据写入 | recorder 后台 flush，减少 I/O 开销 |
| Handler 分发表 | 类属性一次构建，每条消息 O(1) 查找 |
| 循环重连 | while 循环代替递归，不会爆栈 |
| HTTP 连接池 | HTTPAdapter 调大 pool，减少 TLS 握手 |
| 弱网容错 | gzip 损坏跳过、超时自动加大、看门狗检测死连接 |
| WebSocket 缓冲 | SO_RCVBUF=256KB，高流量不丢包 |

## 日志系统

### 日志级别

通过 `config.json` 控制：

| 字段 | 说明 |
|------|------|
| `log_enabled` | `false` 完全关闭日志（控制台+文件），数据文件照常写入 |
| `log_level` | 日志级别：`DEBUG` / `INFO` / `WARNING` / `ERROR` |

| 级别 | 输出内容 |
|------|----------|
| `DEBUG` | 全量，含签名、心跳等调试信息 |
| `INFO` | 弹幕消息 + 连接状态 + 统计（默认） |
| `WARNING` | 仅告警和错误 |
| `ERROR` | 仅错误 |

### 吞吐统计

每 `stats_interval` 秒（默认 60s）自动打印：

```
[吞吐统计] 总计:3420 | 57.0msg/s | [chat:1200, member:800, roomstats:600, like:400, roomuserseq:300]
```

## 弱网兼容

详见 [CONFIG.md](CONFIG.md) 的网络配置章节。

### 支持的能力

- HTTP 超时自动加大（15s → 22s → 33s，封顶 60s）
- DNS 失败指数退避重试
- gzip 损坏包跳过不崩溃
- 看门狗检测静默断连（TCP 连接未正常关闭）
- WebSocket 重连（指数退避 + 抖动，默认无限重连）
- 代理支持（HTTP/HTTPS/SOCKS5）

## 注意事项

1. **仅供学习研究**，严禁用于商业用途
2. **签名脚本**（`sign.js`、`a_bogus.js`）由抖音前端提取
3. **反爬限制**：抖音对频繁请求有限制，建议不要过于频繁地切换直播间
4. **数据隐私**：采集的数据仅用于技术研究，请勿传播
