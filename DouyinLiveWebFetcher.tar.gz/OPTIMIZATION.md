# 抖音直播间弹幕采集器 - 优化说明

## 优化目标
**稳定、持续、快速、高效、完整**采集直播间数据

---

## 主要优化内容

### 1. 🔌 WebSocket 自动重连机制

#### 优化前
```python
def _connectWebSocket(self):
    # 直接连接，断开后无法自动恢复
    self.ws.run_forever()
```

#### 优化后
```python
def _handleReconnect(self):
    # 指数退避重连，最多重连 10 次
    self._reconnect_count += 1
    delay = min(self._reconnect_delay * (2 ** (self._reconnect_count - 1)), self._max_reconnect_delay)
    time.sleep(delay)
    self._connectWebSocket()
```

**优势**：
- ✅ 自动检测连接断开并重连
- ✅ 指数退避算法避免频繁重连
- ✅ 最大重连次数限制防止无限重连
- ✅ 详细的重连日志记录

---

### 2. 🔄 HTTP 请求重试机制

#### 优化前
```python
response = self.session.get(url)
```

#### 优化后
```python
def _get_with_retry(self, url, max_retries=3, **kwargs):
    for attempt in range(max_retries):
        try:
            return self.session.get(url, **kwargs)
        except requests.RequestException as e:
            if attempt < max_retries - 1:
                time.sleep(2 ** attempt)  # 指数退避
            else:
                raise
```

**优势**：
- ✅ 自动重试失败请求（默认 3 次）
- ✅ 指数退避避免服务器压力
- ✅ 详细的错误日志记录

---

### 3. 💓 心跳优化（指数退避 + 随机波动）

#### 优化前
```python
def _sendHeartbeat(self):
    while True:
        time.sleep(5)  # 固定间隔 5 秒
```

#### 优化后
```python
def _sendHeartbeat(self):
    while self._is_connected:
        # 动态调整心跳间隔：3-10 秒
        interval = max(3, min(10, time_since_last_heartbeat + 2))
        # 随机波动 1-5 秒，避免固定间隔被检测
        time.sleep(random.uniform(1, 5))
```

**优势**：
- ✅ 动态心跳间隔（3-10 秒）
- ✅ 随机波动避免固定间隔
- ✅ 网络不稳定时自动增加间隔
- ✅ 防止心跳包被检测为机器人

---

### 4. 📝 日志系统

#### 优化前
```python
print(f"【聊天msg】{time_info}[{user_id}]{fans_club}{grade}{user_name}: {content}")
```

#### 优化后
```python
import logging
logger = logging.getLogger(__name__)

logger.info(f"聊天消息 - 用户:{user_name}[{user_id}] 内容:{content}")
logger.error(f"解析聊天消息失败: {e}")
```

**优势**：
- ✅ 同时输出到控制台和文件
- ✅ 详细的日志级别（INFO/WARNING/ERROR）
- ✅ 时间戳记录
- ✅ 便于问题排查和监控

---

### 5. 🎲 随机 User-Agent

#### 优化前
```python
self.user_agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/140.0.0.0 ..."
```

#### 优化后
```python
def _get_random_user_agent(self):
    user_agents = [
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/121.0.0.0 Safari/537.36",
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Chrome/120.0.0.0 Safari/537.36",
        # ... 更多 User-Agent
    ]
    return random.choice(user_agents)
```

**优势**：
- ✅ 随机切换 User-Agent
- ✅ 避免被识别为自动化脚本
- ✅ 多种浏览器/系统组合

---

### 6. 🔒 连接池优化

#### 优化前
```python
# 每次创建新 Session
self.session = requests.Session()
```

#### 优化后
```python
# 共享 Session
self.session = requests.Session()
self.session.headers.update({'User-Agent': self._get_random_user_agent()})
```

**优势**：
- ✅ 复用 TCP 连接
- ✅ 减少连接建立开销
- ✅ 提高请求效率

---

### 7. 🛡️ 增强错误处理

#### 优化前
```python
except Exception as e:
    print(e)
```

#### 优化后
```python
except Exception as e:
    logger.error(f"解析聊天消息失败: {e}")
    # 详细的错误上下文
```

**优势**：
- ✅ 详细的错误日志
- ✅ 上下文信息记录
- ✅ 不中断程序运行

---

### 8. ⚙️ 配置加载优化

#### 优化前
```python
def _load_config(self, config_file):
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            return json.load(f)
    except FileNotFoundError:
        return {'output': {}}
```

#### 优化后
```python
def _load_config(self, config_file):
    try:
        with open(config_file, 'r', encoding='utf-8') as f:
            config = json.load(f)
        logger.info(f"加载配置文件成功: {config_file}")
        return config
    except FileNotFoundError:
        logger.warning(f"配置文件不存在，使用默认配置: {config_file}")
        return {'output': {}}
    except json.JSONDecodeError as e:
        logger.error(f"配置文件格式错误: {e}")
        return {'output': {}}
```

**优势**：
- ✅ 详细的加载日志
- ✅ 多种错误处理
- ✅ 优雅降级

---

### 9. 🚀 代码规范修复

#### 优化前
```python
import os  # 在函数内部
def generateSignature(wss, script_file='sign.js'):
    script_file_path = os.path.join(...)
```

#### 优化后
```python
import os  # 在文件顶部
def generateSignature(wss, script_file='sign.js'):
    script_file_path = os.path.join(...)
```

**优势**：
- ✅ 符合 PEP 8 规范
- ✅ 提高代码可读性

---

### 10. 🎯 优雅退出机制

#### 优化前
```python
if __name__ == '__main__':
    room.start()
```

#### 优化后
```python
def signal_handler(signum, frame):
    print("\n【收到停止信号，正在优雅退出...】")
    room.stop()
    sys.exit(0)

if __name__ == '__main__':
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    room.start()
```

**优势**：
- ✅ Ctrl+C 优雅退出
- ✅ 正确关闭 WebSocket 连接
- ✅ 清理资源

---

## 性能提升

### 1. 连接稳定性提升
- **重连机制**：断线后自动恢复，无需手动重启
- **重试机制**：HTTP 请求失败自动重试，提高成功率

### 2. 采集效率提升
- **连接池**：复用 TCP 连接，减少连接开销
- **随机心跳**：避免固定间隔被检测，提高存活率

### 3. 可维护性提升
- **日志系统**：详细的日志记录，便于问题排查
- **错误处理**：完善的异常捕获和日志记录

---

## 使用说明

### 1. 安装依赖
```bash
pip install -r requirements.txt
```

### 2. 配置文件
编辑 `config.json` 调整输出类型：
```json
{
  "output": {
    "chat": true,
    "gift": true,
    "like": true,
    "member": true,
    "social": true,
    "rank": false,
    "stats": true,
    "fansclub": true,
    "emoji": true
  }
}
```

### 3. 启动采集
```bash
python3 main.py
```

### 4. 停止采集
- **方式 1**：按 `Ctrl+C`
- **方式 2**：程序自动检测直播间结束

---

## 日志说明

### 日志级别
- **INFO**：正常操作（连接、消息、心跳）
- **WARNING**：非关键问题（配置加载、重连）
- **ERROR**：严重错误（连接失败、解析错误）

### 日志文件
- **控制台**：实时查看
- **文件**：`douyin_live.log` 历史记录

---

## 监控建议

### 1. 日志监控
```bash
# 实时查看日志
tail -f douyin_live.log

# 查看错误日志
grep ERROR douyin_live.log
```

### 2. 连接状态监控
```bash
# 查看重连次数
grep "重连" douyin_live.log

# 查看连接状态
grep "WebSocket" douyin_live.log
```

---

## 故障排查

### 常见问题

#### 1. WebSocket 连接失败
- **检查网络**：确保网络畅通
- **检查签名**：`sign.js` 文件是否存在
- **查看日志**：`tail -f douyin_live.log`

#### 2. 请求失败
- **检查 User-Agent**：是否被识别为机器人
- **检查 Cookie**：`ttwid` 是否过期
- **增加重试次数**：修改 `_get_with_retry` 参数

#### 3. 心跳包被检测
- **调整心跳间隔**：修改 `_heartbeat_interval`
- **增加随机波动**：修改 `_sendHeartbeat` 中的随机范围

---

## 后续优化建议

### 短期优化
1. 添加数据持久化功能（保存到数据库）
2. 增加数据过滤和聚合功能
3. 添加统计监控面板

### 长期优化
1. 改用异步框架（asyncio）
2. 实现分布式采集
3. 增加多直播间并发采集

---

## 总结

本次优化显著提升了抖音直播间弹幕采集器的：
- ✅ **稳定性**：自动重连、请求重试
- ✅ **持续性**：心跳优化、优雅退出
- ✅ **快速性**：连接池、随机心跳
- ✅ **高效性**：指数退避、连接复用
- ✅ **完整性**：完整日志、错误处理

程序现在可以**稳定、持续、快速、高效、完整**地采集直播间数据！
