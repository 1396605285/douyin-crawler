# 抖音直播间弹幕数据采集器

实时抓取抖音直播间 WebSocket 弹幕数据，支持 12 种消息类型，CSV/JSONL 双格式输出。

## 消息类型

| 消息类型 | 说明 | 日志标识 | CSV | JSONL |
|---------|------|----------|-----|-------|
| 聊天消息 | 用户文字弹幕 | `聊天消息` | ✅ | ✅ |
| 进场消息 | 用户进入直播间 | `进场消息` | ✅ | ✅ |
| 点赞消息 | 用户双击点赞 | `点赞消息` | ✅ | ✅ |
| 关注/分享 | 关注主播或分享直播间 | `关注/分享消息` | ✅ | ✅ |
| 礼物消息 | 用户赠送礼物（含抖币计算） | `礼物消息` | ✅ | ✅ |
| 粉丝团消息 | 加入/升级粉丝团 | `粉丝团消息` | ✅ | ✅ |
| 表情消息 | 用户发送表情包 | `表情消息` | ✅ | ✅ |
| 统计消息 | 实时在线人数 | `统计消息` | ✅ | ✅ |
| 直播间统计 | 累计观看等 | `直播间统计信息` | ✅ | ✅ |
| 直播间信息 | 置顶公告等 | `直播间信息` | ✅ | ✅ |
| 排行榜 | 积分排行榜 | `排行榜消息` | ✅ | ✅ |
| 直播间状态 | 开始/暂停/结束 | `直播间状态` | ✅ | ✅ |

## 环境要求

- Python 3.8+
- Node.js（用于执行 JavaScript 签名脚本）

## 安装

```bash
pip install -r requirements.txt
```

| 包名 | 用途 |
|------|------|
| `requests` | HTTP 请求 |
| `websocket-client` | WebSocket 连接 |
| `protobuf` | Protobuf 序列化 |
| `proto-plus` | Protobuf 反序列化 |

## 使用

```bash
# 无参数显示用法
python3 main.py

# 指定直播间
python3 main.py 536863152858

# 指定配置文件
python3 main.py 536863152858 -c config.json

# 覆盖日志级别
python3 main.py 536863152858 --log-level DEBUG

# 停止采集
Ctrl+C
```

## 配置

编辑 `config.json`，详见 [CONFIG.md](CONFIG.md)。

```json
{
  "log_enabled": true,
  "log_level": "INFO",
  "output": {
    "chat": true,
    "gift": true,
    "like": true,
    "member": true,
    "social": true,
    "rank": true,
    "stats": true,
    "fansclub": true,
    "emoji": true,
    "room": true,
    "roomstats": true,
    "control": true,
    "file_format": "json",
    "file_dir": "data"
  },
  "network": {
    "http_timeout": 15,
    "ws_connect_timeout": 30,
    "silence_timeout": 60,
    "heartbeat_interval": 10,
    "rcvbuf_kb": 256,
    "proxy": null
  },
  "max_reconnects": 0,
  "reconnect_base_delay": 2,
  "reconnect_max_delay": 120,
  "stats_interval": 60
}
```

### output 开关

每种消息类型可独立开关。设为 `false` 时：不显示日志、不写入数据、不创建 CSV 文件。

### file_format

| 值 | 说明 |
|----|------|
| `none` | 仅输出到日志 |
| `csv` | 按消息类型分 CSV 文件 |
| `json` | JSONL 格式，所有消息写入一个文件 |
| `both` | CSV + JSONL 同时输出 |

## 数据输出

### 路径结构

```
data/{live_id}/{年月}/
├── 20260412_124806.jsonl
├── 20260412_124806_chat.csv
├── 20260412_124806_gift.csv
├── 20260412_124806_like.csv
├── 20260412_124806_member.csv
├── 20260412_124806_social.csv
├── 20260412_124806_fansclub.csv
├── 20260412_124806_emoji.csv
├── 20260412_124806_stats.csv
├── 20260412_124806_roomstats.csv
├── 20260412_124806_room.csv
├── 20260412_124806_rank.csv
└── 20260412_124806_control.csv
```

- 按直播 ID 建文件夹，按年月分目录
- 文件名格式：`{时间戳}_{类型}.{扩展名}`
- CSV UTF-8 BOM 编码，可直接用 Excel 打开

### CSV 字段

| 类型 | 字段 |
|------|------|
| chat | time, user_id, user_name, content, grade, fans_club |
| gift | time, user_id, user_name, gift_name, gift_count, diamond_total, grade, fans_club |
| like | time, user_id, user_name, count, total, grade, fans_club |
| member | time, user_id, user_name, gender, grade, fans_club, member_count |
| social | time, user_id, user_name, action, grade, fans_club |
| fansclub | time, user_id, user_name, type, content, grade, fans_club |
| emoji | time, user_id, user_name, emoji_id, content, grade, fans_club |
| stats | time, current, total_pv, total_user, online_anchor |
| roomstats | time, detail, total |
| room | time, is_top, room_id, content, biz_scene |
| rank | time, ranks |
| control | time, status |

### JSONL 示例

```json
{"type": "chat", "ts": 1775954555.948, "data": {"time": "08:36:55", "user_id": "97992671880", "user_name": "幸运星陈", "content": "让我看看哪个美女好看？", "grade": "[等级6]", "fans_club": "[粉丝团 Lv1]"}}
```

## 运行机制

```
1. 获取 ttwid      → HTTP 请求 live.douyin.com，获取 Cookie
2. 获取 roomId     → 解析页面，三重正则提取真实 roomId
3. 生成签名        → 参数拼接 → MD5 → Node.js 执行 sign.js
4. WebSocket 连接  → 携带 ttwid + 签名建立长连接
5. 消息处理        → PushFrame → gzip 解压 → Response → 按 method 分发
6. 数据输出        → 日志 + CSV/JSONL 批量写入
```

## 线程模型

| 线程名 | 职责 | 生命周期 |
|--------|------|----------|
| MainThread | 运行 `run_forever()` 阻塞接收 WS 消息 | 主线程 |
| heartbeat | 每 10s 发送业务层心跳包 | daemon |
| watchdog | 每 3~10s 检查静默断连 | daemon |
| stats | 每 60s 打印吞吐统计 | daemon |
| log-drain | 每 0.5s drain 日志队列写文件/控制台 | daemon |
| recorder-flush | 每 2s 批量写 JSONL/CSV | daemon |

### 数据流

```
WS 回调 → logger.info() → _QueueHandler (deque) → log-drain → 文件/控制台
         → recorder.record() → DataRecorder (deque) → recorder-flush → JSONL/CSV
```

## 弱网容错

- HTTP 超时自动加大（15s → 22s → 33s，封顶 60s）
- DNS 失败指数退避重试
- gzip 损坏包跳过不崩溃
- 看门狗检测静默断连（TCP 假活）
- WebSocket 重连（指数退避 + 随机抖动，默认无限重连）
- 代理支持（HTTP/HTTPS/SOCKS5）

## 项目结构

```
├── main.py              启动入口
├── live_crawler.py      核心模块（网络/解析/记录）
├── live_messages.py     Protobuf 消息定义
├── sign.js              抖音签名脚本
├── sign_runner.js       签名执行桥接
├── config.json          运行配置
├── test_live_crawler.py 单元测试
└── data/                数据输出
```

## 日志

| 字段 | 说明 |
|------|------|
| `log_enabled` | `false` 完全关闭日志，数据文件照常写入 |
| `log_level` | `DEBUG` / `INFO` / `WARNING` / `ERROR` |

每 `stats_interval` 秒打印吞吐统计：

```
[吞吐统计] 总计:3420 | 57.0msg/s | [chat:1200, member:800, roomstats:600, like:400, roomuserseq:300]
```

## 注意事项

1. **仅供学习研究**，严禁用于商业用途
2. 签名脚本 `sign.js` 由抖音前端提取，可能随版本更新失效
3. 抖音对频繁请求有限制，建议不要过于频繁切换直播间
4. 采集的数据仅用于技术研究，请勿传播
