const fs = require("fs");
eval(fs.readFileSync(__dirname + "/sign.js", "utf8"));
const input = fs.readFileSync("/dev/stdin", "utf8").trim();
try {
    process.stdout.write(crawler({"X-MS-STUB": input})["X-Bogus"] || "");
} catch(e) {
    process.stderr.write("sign error: " + e.message);
    process.exit(1);
}
process.exit(0);
