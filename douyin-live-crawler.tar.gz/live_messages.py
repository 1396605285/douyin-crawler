# Protobuf message definitions for Douyin Live
# Migrated from betterproto to proto-plus (Google maintained, C-extension backed)
import proto


# ── Enums (proto-plus doesn't have native Enum, use int constants) ──

class CommentTypeTag:
    COMMENTTYPETAGUNKNOWN = 0
    COMMENTTYPETAGSTAR = 1


class RoomMsgTypeEnum:
    DEFAULTROOMMSG = 0
    ECOMLIVEREPLAYSAVEROOMMSG = 1
    CONSUMERRELATIONROOMMSG = 2
    JUMANJIDATAAUTHNOTIFYMSG = 3
    VSWELCOMEMSG = 4
    MINORREFUNDMSG = 5
    PAIDLIVEROOMNOTIFYANCHORMSG = 6
    HOSTTEAMSYSTEMMSG = 7


# ── Core messages (used in WebSocket pipeline) ──

class Message(proto.Message):
    method = proto.Field(proto.STRING, number=1)
    payload = proto.Field(proto.BYTES, number=2)
    msg_id = proto.Field(proto.INT64, number=3)
    msg_type = proto.Field(proto.INT32, number=4)
    offset = proto.Field(proto.INT64, number=5)
    need_wrds_store = proto.Field(proto.BOOL, number=6)
    wrds_version = proto.Field(proto.INT64, number=7)
    wrds_sub_key = proto.Field(proto.STRING, number=8)


class Response(proto.Message):
    messages_list = proto.RepeatedField(Message, number=1)
    cursor = proto.Field(proto.STRING, number=2)
    fetch_interval = proto.Field(proto.UINT64, number=3)
    now = proto.Field(proto.UINT64, number=4)
    internal_ext = proto.Field(proto.STRING, number=5)
    fetch_type = proto.Field(proto.UINT32, number=6)
    route_params = proto.MapField(proto.STRING, proto.STRING, number=7)
    heartbeat_duration = proto.Field(proto.UINT64, number=8)
    need_ack = proto.Field(proto.BOOL, number=9)
    push_server = proto.Field(proto.STRING, number=10)
    live_cursor = proto.Field(proto.STRING, number=11)
    history_no_more = proto.Field(proto.BOOL, number=12)


class HeadersList(proto.Message):
    key = proto.Field(proto.STRING, number=1)
    value = proto.Field(proto.STRING, number=2)


class PushFrame(proto.Message):
    seq_id = proto.Field(proto.UINT64, number=1)
    log_id = proto.Field(proto.UINT64, number=2)
    service = proto.Field(proto.UINT64, number=3)
    method = proto.Field(proto.UINT64, number=4)
    headers_list = proto.RepeatedField(HeadersList, number=5)
    payload_encoding = proto.Field(proto.STRING, number=6)
    payload_type = proto.Field(proto.STRING, number=7)
    payload = proto.Field(proto.BYTES, number=8)


# ── Common / User / Image (shared by many messages) ──

class Image(proto.Message):
    url_list_list = proto.RepeatedField(proto.STRING, number=1)
    uri = proto.Field(proto.STRING, number=2)
    height = proto.Field(proto.UINT64, number=3)
    width = proto.Field(proto.UINT64, number=4)
    avg_color = proto.Field(proto.STRING, number=5)
    image_type = proto.Field(proto.UINT32, number=6)
    open_web_url = proto.Field(proto.STRING, number=7)
    content = proto.Field("ImageContent", number=8)
    is_animated = proto.Field(proto.BOOL, number=9)
    flex_setting_list = proto.Field("NinePatchSetting", number=10)
    text_setting_list = proto.Field("NinePatchSetting", number=11)


class NinePatchSetting(proto.Message):
    setting_list_list = proto.RepeatedField(proto.STRING, number=1)


class ImageContent(proto.Message):
    name = proto.Field(proto.STRING, number=1)
    font_color = proto.Field(proto.STRING, number=2)
    level = proto.Field(proto.UINT64, number=3)
    alternative_text = proto.Field(proto.STRING, number=4)


class TextFormat(proto.Message):
    color = proto.Field(proto.STRING, number=1)
    bold = proto.Field(proto.BOOL, number=2)
    italic = proto.Field(proto.BOOL, number=3)
    weight = proto.Field(proto.UINT32, number=4)
    italic_angle = proto.Field(proto.UINT32, number=5)
    font_size = proto.Field(proto.UINT32, number=6)
    use_heigh_light_color = proto.Field(proto.BOOL, number=7)
    use_remote_clor = proto.Field(proto.BOOL, number=8)


class TextPieceUser(proto.Message):
    user = proto.Field("User", number=1)
    with_colon = proto.Field(proto.BOOL, number=2)


class TextPieceGift(proto.Message):
    gift_id = proto.Field(proto.UINT64, number=1)
    name_ref = proto.Field("PatternRef", number=2)


class PatternRef(proto.Message):
    key = proto.Field(proto.STRING, number=1)
    default_pattern = proto.Field(proto.STRING, number=2)


class TextPieceHeart(proto.Message):
    color = proto.Field(proto.STRING, number=1)


class TextPiecePatternRef(proto.Message):
    key = proto.Field(proto.STRING, number=1)
    default_pattern = proto.Field(proto.STRING, number=2)


class TextPieceImage(proto.Message):
    image = proto.Field(Image, number=1)
    scaling_rate = proto.Field(proto.FLOAT, number=2)


class TextPiece(proto.Message):
    type = proto.Field(proto.BOOL, number=1)
    format = proto.Field(TextFormat, number=2)
    string_value = proto.Field(proto.STRING, number=3)
    user_value = proto.Field(TextPieceUser, number=4)
    gift_value = proto.Field(TextPieceGift, number=5)
    heart_value = proto.Field(TextPieceHeart, number=6)
    pattern_ref_value = proto.Field(TextPiecePatternRef, number=7)
    image_value = proto.Field(TextPieceImage, number=8)


class Text(proto.Message):
    key = proto.Field(proto.STRING, number=1)
    default_patter = proto.Field(proto.STRING, number=2)
    default_format = proto.Field(TextFormat, number=3)
    pieces_list = proto.RepeatedField(TextPiece, number=4)


class FollowInfo(proto.Message):
    following_count = proto.Field(proto.UINT64, number=1)
    follower_count = proto.Field(proto.UINT64, number=2)
    follow_status = proto.Field(proto.UINT64, number=3)
    push_status = proto.Field(proto.UINT64, number=4)
    remark_name = proto.Field(proto.STRING, number=5)
    follower_count_str = proto.Field(proto.STRING, number=6)
    following_count_str = proto.Field(proto.STRING, number=7)


class GradeIcon(proto.Message):
    icon = proto.Field(Image, number=1)
    icon_diamond = proto.Field(proto.INT64, number=2)
    level = proto.Field(proto.INT64, number=3)
    level_str = proto.Field(proto.STRING, number=4)


class GradeBuffInfo(proto.Message):
    pass


class PayGrade(proto.Message):
    total_diamond_count = proto.Field(proto.INT64, number=1)
    diamond_icon = proto.Field(Image, number=2)
    name = proto.Field(proto.STRING, number=3)
    icon = proto.Field(Image, number=4)
    next_name = proto.Field(proto.STRING, number=5)
    level = proto.Field(proto.INT64, number=6)
    next_icon = proto.Field(Image, number=7)
    next_diamond = proto.Field(proto.INT64, number=8)
    now_diamond = proto.Field(proto.INT64, number=9)
    this_grade_min_diamond = proto.Field(proto.INT64, number=10)
    this_grade_max_diamond = proto.Field(proto.INT64, number=11)
    pay_diamond_bak = proto.Field(proto.INT64, number=12)
    grade_describe = proto.Field(proto.STRING, number=13)
    grade_icon_list = proto.RepeatedField(GradeIcon, number=14)
    screen_chat_type = proto.Field(proto.INT64, number=15)
    im_icon = proto.Field(Image, number=16)
    im_icon_with_level = proto.Field(Image, number=17)
    live_icon = proto.Field(Image, number=18)
    new_im_icon_with_level = proto.Field(Image, number=19)
    new_live_icon = proto.Field(Image, number=20)
    upgrade_need_consume = proto.Field(proto.INT64, number=21)
    next_privileges = proto.Field(proto.STRING, number=22)
    background = proto.Field(Image, number=23)
    background_back = proto.Field(Image, number=24)
    score = proto.Field(proto.INT64, number=25)
    buff_info = proto.Field(GradeBuffInfo, number=26)
    grade_banner = proto.Field(proto.STRING, number=1001)
    profile_dialog_bg = proto.Field(Image, number=1002)
    profile_dialog_bg_back = proto.Field(Image, number=1003)


class UserBadge(proto.Message):
    icons = proto.MapField(proto.INT32, Image, number=1)
    title = proto.Field(proto.STRING, number=2)


class FansClubData(proto.Message):
    club_name = proto.Field(proto.STRING, number=1)
    level = proto.Field(proto.INT32, number=2)
    user_fans_club_status = proto.Field(proto.INT32, number=3)
    badge = proto.Field(UserBadge, number=4)
    available_gift_ids = proto.RepeatedField(proto.INT64, number=5)
    anchor_id = proto.Field(proto.INT64, number=6)


class FansClub(proto.Message):
    data = proto.Field(FansClubData, number=1)
    prefer_data = proto.MapField(proto.INT32, FansClubData, number=2)


class User(proto.Message):
    id = proto.Field(proto.UINT64, number=1)
    short_id = proto.Field(proto.UINT64, number=2)
    nick_name = proto.Field(proto.STRING, number=3)
    gender = proto.Field(proto.UINT32, number=4)
    signature = proto.Field(proto.STRING, number=5)
    level = proto.Field(proto.UINT32, number=6)
    birthday = proto.Field(proto.UINT64, number=7)
    telephone = proto.Field(proto.STRING, number=8)
    avatar_thumb = proto.Field(Image, number=9)
    avatar_medium = proto.Field(Image, number=10)
    avatar_large = proto.Field(Image, number=11)
    verified = proto.Field(proto.BOOL, number=12)
    experience = proto.Field(proto.UINT32, number=13)
    city = proto.Field(proto.STRING, number=14)
    status = proto.Field(proto.INT32, number=15)
    create_time = proto.Field(proto.UINT64, number=16)
    modify_time = proto.Field(proto.UINT64, number=17)
    secret = proto.Field(proto.UINT32, number=18)
    share_qrcode_uri = proto.Field(proto.STRING, number=19)
    income_share_percent = proto.Field(proto.UINT32, number=20)
    badge_image_list = proto.RepeatedField(Image, number=21)
    follow_info = proto.Field(FollowInfo, number=22)
    pay_grade = proto.Field(PayGrade, number=23)
    fans_club = proto.Field(FansClub, number=24)
    special_id = proto.Field(proto.STRING, number=26)
    avatar_border = proto.Field(Image, number=27)
    medal = proto.Field(Image, number=28)
    real_time_icons_list = proto.RepeatedField(Image, number=29)
    display_id = proto.Field(proto.STRING, number=38)
    sec_uid = proto.Field(proto.STRING, number=46)
    fan_ticket_count = proto.Field(proto.UINT64, number=1022)
    id_str = proto.Field(proto.STRING, number=1028)
    age_range = proto.Field(proto.UINT32, number=1045)


class Common(proto.Message):
    method = proto.Field(proto.STRING, number=1)
    msg_id = proto.Field(proto.UINT64, number=2)
    room_id = proto.Field(proto.UINT64, number=3)
    create_time = proto.Field(proto.UINT64, number=4)
    monitor = proto.Field(proto.UINT32, number=5)
    is_show_msg = proto.Field(proto.BOOL, number=6)
    describe = proto.Field(proto.STRING, number=7)
    fold_type = proto.Field(proto.UINT64, number=9)
    anchor_fold_type = proto.Field(proto.UINT64, number=10)
    priority_score = proto.Field(proto.UINT64, number=11)
    log_id = proto.Field(proto.STRING, number=12)
    msg_process_filter_k = proto.Field(proto.STRING, number=13)
    msg_process_filter_v = proto.Field(proto.STRING, number=14)
    user = proto.Field(User, number=15)
    anchor_fold_type_v2 = proto.Field(proto.UINT64, number=17)
    process_at_sei_time_ms = proto.Field(proto.UINT64, number=18)
    random_dispatch_ms = proto.Field(proto.UINT64, number=19)
    is_dispatch = proto.Field(proto.BOOL, number=20)
    channel_id = proto.Field(proto.UINT64, number=21)
    diff_sei2abs_second = proto.Field(proto.UINT64, number=22)
    anchor_fold_duration = proto.Field(proto.UINT64, number=23)


class PublicAreaCommon(proto.Message):
    user_label = proto.Field(Image, number=1)
    user_consume_in_room = proto.Field(proto.UINT64, number=2)
    user_send_gift_cnt_in_room = proto.Field(proto.UINT64, number=3)


class LandscapeAreaCommon(proto.Message):
    show_head = proto.Field(proto.BOOL, number=1)
    show_nickname = proto.Field(proto.BOOL, number=2)
    show_font_color = proto.Field(proto.BOOL, number=3)
    color_value_list = proto.RepeatedField(proto.STRING, number=4)
    comment_type_tags_list = proto.RepeatedField(proto.INT32, number=5)


class EffectConfig(proto.Message):
    type = proto.Field(proto.UINT64, number=1)
    icon = proto.Field(Image, number=2)
    avatar_pos = proto.Field(proto.UINT64, number=3)
    text = proto.Field(Text, number=4)
    text_icon = proto.Field(Image, number=5)
    stay_time = proto.Field(proto.UINT32, number=6)
    anim_asset_id = proto.Field(proto.UINT64, number=7)
    badge = proto.Field(Image, number=8)
    flex_setting_array_list = proto.RepeatedField(proto.UINT64, number=9)
    text_icon_overlay = proto.Field(Image, number=10)
    animated_badge = proto.Field(Image, number=11)
    has_sweep_light = proto.Field(proto.BOOL, number=12)
    text_flex_setting_array_list = proto.RepeatedField(proto.UINT64, number=13)
    center_anim_asset_id = proto.Field(proto.UINT64, number=14)
    dynamic_image = proto.Field(Image, number=15)
    extra_map = proto.MapField(proto.STRING, proto.STRING, number=16)
    mp4_anim_asset_id = proto.Field(proto.UINT64, number=17)
    priority = proto.Field(proto.UINT64, number=18)
    max_wait_time = proto.Field(proto.UINT64, number=19)
    dress_id = proto.Field(proto.STRING, number=20)
    alignment = proto.Field(proto.UINT64, number=21)
    alignment_offset = proto.Field(proto.UINT64, number=22)


# ── Chat messages ──

class ChatMessage(proto.Message):
    common = proto.Field(Common, number=1)
    user = proto.Field(User, number=2)
    content = proto.Field(proto.STRING, number=3)
    visible_to_sender = proto.Field(proto.BOOL, number=4)
    background_image = proto.Field(Image, number=5)
    full_screen_text_color = proto.Field(proto.STRING, number=6)
    background_image_v2 = proto.Field(Image, number=7)
    public_area_common = proto.Field(PublicAreaCommon, number=9)
    gift_image = proto.Field(Image, number=10)
    agree_msg_id = proto.Field(proto.UINT64, number=11)
    priority_level = proto.Field(proto.UINT32, number=12)
    landscape_area_common = proto.Field(LandscapeAreaCommon, number=13)
    event_time = proto.Field(proto.UINT64, number=15)
    send_review = proto.Field(proto.BOOL, number=16)
    from_intercom = proto.Field(proto.BOOL, number=17)
    intercom_hide_user_card = proto.Field(proto.BOOL, number=18)
    chat_by = proto.Field(proto.STRING, number=20)
    individual_chat_priority = proto.Field(proto.UINT32, number=21)
    rtf_content = proto.Field(Text, number=22)


class EmojiChatMessage(proto.Message):
    common = proto.Field(Common, number=1)
    user = proto.Field(User, number=2)
    emoji_id = proto.Field(proto.INT64, number=3)
    emoji_content = proto.Field(Text, number=4)
    default_content = proto.Field(proto.STRING, number=5)
    background_image = proto.Field(Image, number=6)
    from_intercom = proto.Field(proto.BOOL, number=7)
    intercom_hide_user_card = proto.Field(proto.BOOL, number=8)


# ── Room stats ──

class RoomUserSeqMessageContributor(proto.Message):
    score = proto.Field(proto.UINT64, number=1)
    user = proto.Field(User, number=2)
    rank = proto.Field(proto.UINT64, number=3)
    delta = proto.Field(proto.UINT64, number=4)
    is_hidden = proto.Field(proto.BOOL, number=5)
    score_description = proto.Field(proto.STRING, number=6)
    exactly_score = proto.Field(proto.STRING, number=7)


class RoomUserSeqMessage(proto.Message):
    common = proto.Field(Common, number=1)
    ranks_list = proto.RepeatedField(RoomUserSeqMessageContributor, number=2)
    total = proto.Field(proto.INT64, number=3)
    pop_str = proto.Field(proto.STRING, number=4)
    seats_list = proto.RepeatedField(RoomUserSeqMessageContributor, number=5)
    popularity = proto.Field(proto.INT64, number=6)
    total_user = proto.Field(proto.INT64, number=7)
    total_user_str = proto.Field(proto.STRING, number=8)
    total_str = proto.Field(proto.STRING, number=9)
    online_user_for_anchor = proto.Field(proto.STRING, number=10)
    total_pv_for_anchor = proto.Field(proto.STRING, number=11)
    up_right_stats_str = proto.Field(proto.STRING, number=12)
    up_right_stats_str_complete = proto.Field(proto.STRING, number=13)


class RoomStatsMessage(proto.Message):
    common = proto.Field(Common, number=1)
    display_short = proto.Field(proto.STRING, number=2)
    display_middle = proto.Field(proto.STRING, number=3)
    display_long = proto.Field(proto.STRING, number=4)
    display_value = proto.Field(proto.INT64, number=5)
    display_version = proto.Field(proto.INT64, number=6)
    incremental = proto.Field(proto.BOOL, number=7)
    is_hidden = proto.Field(proto.BOOL, number=8)
    total = proto.Field(proto.INT64, number=9)
    display_type = proto.Field(proto.INT64, number=10)


# ── Gift messages ──

class GiftStruct(proto.Message):
    image = proto.Field(Image, number=1)
    describe = proto.Field(proto.STRING, number=2)
    notify = proto.Field(proto.BOOL, number=3)
    duration = proto.Field(proto.UINT64, number=4)
    id = proto.Field(proto.UINT64, number=5)
    for_linkmic = proto.Field(proto.BOOL, number=7)
    doodle = proto.Field(proto.BOOL, number=8)
    for_fansclub = proto.Field(proto.BOOL, number=9)
    combo = proto.Field(proto.BOOL, number=10)
    type = proto.Field(proto.UINT32, number=11)
    diamond_count = proto.Field(proto.UINT32, number=12)
    is_displayed_on_panel = proto.Field(proto.BOOL, number=13)
    primary_effect_id = proto.Field(proto.UINT64, number=14)
    gift_label_icon = proto.Field(Image, number=15)
    name = proto.Field(proto.STRING, number=16)
    region = proto.Field(proto.STRING, number=17)
    manual = proto.Field(proto.STRING, number=18)
    for_custom = proto.Field(proto.BOOL, number=19)
    icon = proto.Field(Image, number=21)
    action_type = proto.Field(proto.UINT32, number=22)


class GiftIMPriority(proto.Message):
    queue_sizes_list = proto.RepeatedField(proto.UINT64, number=1)
    self_queue_priority = proto.Field(proto.UINT64, number=2)
    priority = proto.Field(proto.UINT64, number=3)


class TextEffectDetail(proto.Message):
    text = proto.Field(Text, number=1)
    text_font_size = proto.Field(proto.UINT32, number=2)
    background = proto.Field(Image, number=3)
    start = proto.Field(proto.UINT32, number=4)
    duration = proto.Field(proto.UINT32, number=5)
    x = proto.Field(proto.UINT32, number=6)
    y = proto.Field(proto.UINT32, number=7)
    width = proto.Field(proto.UINT32, number=8)
    height = proto.Field(proto.UINT32, number=9)
    shadow_dx = proto.Field(proto.UINT32, number=10)
    shadow_dy = proto.Field(proto.UINT32, number=11)
    shadow_radius = proto.Field(proto.UINT32, number=12)
    shadow_color = proto.Field(proto.STRING, number=13)
    stroke_color = proto.Field(proto.STRING, number=14)
    stroke_width = proto.Field(proto.UINT32, number=15)


class TextEffect(proto.Message):
    portrait = proto.Field(TextEffectDetail, number=1)
    landscape = proto.Field(TextEffectDetail, number=2)


class GiftMessage(proto.Message):
    common = proto.Field(Common, number=1)
    gift_id = proto.Field(proto.UINT64, number=2)
    fan_ticket_count = proto.Field(proto.UINT64, number=3)
    group_count = proto.Field(proto.UINT64, number=4)
    repeat_count = proto.Field(proto.UINT64, number=5)
    combo_count = proto.Field(proto.UINT64, number=6)
    user = proto.Field(User, number=7)
    to_user = proto.Field(User, number=8)
    repeat_end = proto.Field(proto.UINT32, number=9)
    text_effect = proto.Field(TextEffect, number=10)
    group_id = proto.Field(proto.UINT64, number=11)
    income_taskgifts = proto.Field(proto.UINT64, number=12)
    room_fan_ticket_count = proto.Field(proto.UINT64, number=13)
    priority = proto.Field(GiftIMPriority, number=14)
    gift = proto.Field(GiftStruct, number=15)
    log_id = proto.Field(proto.STRING, number=16)
    send_type = proto.Field(proto.UINT64, number=17)
    public_area_common = proto.Field(PublicAreaCommon, number=18)
    tray_display_text = proto.Field(Text, number=19)
    banned_display_effects = proto.Field(proto.UINT64, number=20)
    display_for_self = proto.Field(proto.BOOL, number=25)
    interact_gift_info = proto.Field(proto.STRING, number=26)
    diy_item_info = proto.Field(proto.STRING, number=27)
    min_asset_set_list = proto.RepeatedField(proto.UINT64, number=28)
    total_count = proto.Field(proto.UINT64, number=29)
    client_gift_source = proto.Field(proto.UINT32, number=30)
    to_user_ids_list = proto.RepeatedField(proto.UINT64, number=32)
    send_time = proto.Field(proto.UINT64, number=33)
    force_display_effects = proto.Field(proto.UINT64, number=34)
    trace_id = proto.Field(proto.STRING, number=35)
    effect_display_ts = proto.Field(proto.UINT64, number=36)


# ── Social / Like / Member ──

class MemberMessage(proto.Message):
    common = proto.Field(Common, number=1)
    user = proto.Field(User, number=2)
    member_count = proto.Field(proto.UINT64, number=3)
    operator = proto.Field(User, number=4)
    is_set_to_admin = proto.Field(proto.BOOL, number=5)
    is_top_user = proto.Field(proto.BOOL, number=6)
    rank_score = proto.Field(proto.UINT64, number=7)
    top_user_no = proto.Field(proto.UINT64, number=8)
    enter_type = proto.Field(proto.UINT64, number=9)
    action = proto.Field(proto.UINT64, number=10)
    action_description = proto.Field(proto.STRING, number=11)
    user_id = proto.Field(proto.UINT64, number=12)
    effect_config = proto.Field(EffectConfig, number=13)
    pop_str = proto.Field(proto.STRING, number=14)
    enter_effect_config = proto.Field(EffectConfig, number=15)
    background_image = proto.Field(Image, number=16)
    background_image_v2 = proto.Field(Image, number=17)
    anchor_display_text = proto.Field(Text, number=18)
    public_area_common = proto.Field(PublicAreaCommon, number=19)
    user_enter_tip_type = proto.Field(proto.UINT64, number=20)
    anchor_enter_tip_type = proto.Field(proto.UINT64, number=21)


class LikeMessage(proto.Message):
    common = proto.Field(Common, number=1)
    count = proto.Field(proto.UINT64, number=2)
    total = proto.Field(proto.UINT64, number=3)
    color = proto.Field(proto.UINT64, number=4)
    user = proto.Field(User, number=5)
    icon = proto.Field(proto.STRING, number=6)
    double_like_detail = proto.Field("DoubleLikeDetail", number=7)
    display_control_info = proto.Field("DisplayControlInfo", number=8)
    linkmic_guest_uid = proto.Field(proto.UINT64, number=9)
    scene = proto.Field(proto.STRING, number=10)
    pico_display_info = proto.Field("PicoDisplayInfo", number=11)


class DoubleLikeDetail(proto.Message):
    double_flag = proto.Field(proto.BOOL, number=1)
    seq_id = proto.Field(proto.UINT32, number=2)
    renewals_num = proto.Field(proto.UINT32, number=3)
    triggers_num = proto.Field(proto.UINT32, number=4)


class DisplayControlInfo(proto.Message):
    show_text = proto.Field(proto.BOOL, number=1)
    show_icons = proto.Field(proto.BOOL, number=2)


class PicoDisplayInfo(proto.Message):
    combo_sum_count = proto.Field(proto.UINT64, number=1)
    emoji = proto.Field(proto.STRING, number=2)
    emoji_icon = proto.Field(Image, number=3)
    emoji_text = proto.Field(proto.STRING, number=4)


class SocialMessage(proto.Message):
    common = proto.Field(Common, number=1)
    user = proto.Field(User, number=2)
    share_type = proto.Field(proto.UINT64, number=3)
    action = proto.Field(proto.UINT64, number=4)
    share_target = proto.Field(proto.STRING, number=5)
    follow_count = proto.Field(proto.UINT64, number=6)
    public_area_common = proto.Field(PublicAreaCommon, number=7)


# ── Fans club ──

class FansclubMessage(proto.Message):
    common_info = proto.Field(Common, number=1)
    type = proto.Field(proto.INT32, number=2)
    content = proto.Field(proto.STRING, number=3)
    user = proto.Field(User, number=4)


# ── Room messages ──

class CommonTextMessage(proto.Message):
    common = proto.Field(Common, number=1)
    user = proto.Field(User, number=2)
    scene = proto.Field(proto.STRING, number=3)


class UpdateFanTicketMessage(proto.Message):
    common = proto.Field(Common, number=1)
    room_fan_ticket_count_text = proto.Field(proto.STRING, number=2)
    room_fan_ticket_count = proto.Field(proto.UINT64, number=3)
    force_update = proto.Field(proto.BOOL, number=4)


class ControlMessage(proto.Message):
    common = proto.Field(Common, number=1)
    status = proto.Field(proto.INT32, number=2)


class RoomRankMessageRoomRank(proto.Message):
    user = proto.Field(User, number=1)
    score_str = proto.Field(proto.STRING, number=2)
    profile_hidden = proto.Field(proto.BOOL, number=3)


class RoomRankMessage(proto.Message):
    common = proto.Field(Common, number=1)
    ranks_list = proto.RepeatedField(RoomRankMessageRoomRank, number=2)


class RoomMessage(proto.Message):
    common = proto.Field(Common, number=1)
    content = proto.Field(proto.STRING, number=2)
    supprot_landscape = proto.Field(proto.BOOL, number=3)
    roommessagetype = proto.Field(proto.INT32, number=4)
    system_top_msg = proto.Field(proto.BOOL, number=5)
    forced_guarantee = proto.Field(proto.BOOL, number=6)
    biz_scene = proto.Field(proto.STRING, number=20)
    buried_point_map = proto.MapField(proto.STRING, proto.STRING, number=30)


class RoomStreamAdaptationMessage(proto.Message):
    common = proto.Field(Common, number=1)
    adaptation_type = proto.Field(proto.INT32, number=2)
    adaptation_height_ratio = proto.Field(proto.FLOAT, number=3)
    adaptation_body_center_ratio = proto.Field(proto.FLOAT, number=4)


# ── Shopping / Product ──

class LiveShoppingMessage(proto.Message):
    common = proto.Field(Common, number=1)
    msg_type = proto.Field(proto.INT32, number=2)
    promotion_id = proto.Field(proto.INT64, number=4)


class ProductInfo(proto.Message):
    promotion_id = proto.Field(proto.INT64, number=1)
    index = proto.Field(proto.INT32, number=2)
    target_flash_uids_list = proto.RepeatedField(proto.INT64, number=3)
    explain_type = proto.Field(proto.INT64, number=4)


class CategoryInfo(proto.Message):
    id = proto.Field(proto.INT32, number=1)
    name = proto.Field(proto.STRING, number=2)
    promotion_ids_list = proto.RepeatedField(proto.INT64, number=3)
    type = proto.Field(proto.STRING, number=4)
    unique_index = proto.Field(proto.STRING, number=5)


class ProductChangeMessage(proto.Message):
    common = proto.Field(Common, number=1)
    update_timestamp = proto.Field(proto.INT64, number=2)
    update_toast = proto.Field(proto.STRING, number=3)
    update_product_info_list = proto.RepeatedField(ProductInfo, number=4)
    total = proto.Field(proto.INT64, number=5)
    update_category_info_list = proto.RepeatedField(CategoryInfo, number=8)


# ── Match / Episode ──

class Against(proto.Message):
    left_name = proto.Field(proto.STRING, number=1)
    left_logo = proto.Field(Image, number=2)
    left_goal = proto.Field(proto.STRING, number=3)
    right_name = proto.Field(proto.STRING, number=6)
    right_logo = proto.Field(Image, number=7)
    right_goal = proto.Field(proto.STRING, number=8)
    timestamp = proto.Field(proto.UINT64, number=11)
    version = proto.Field(proto.UINT64, number=12)
    left_team_id = proto.Field(proto.UINT64, number=13)
    right_team_id = proto.Field(proto.UINT64, number=14)
    diff_sei2abs_second = proto.Field(proto.UINT64, number=15)
    final_goal_stage = proto.Field(proto.UINT32, number=16)
    current_goal_stage = proto.Field(proto.UINT32, number=17)
    left_score_addition = proto.Field(proto.UINT32, number=18)
    right_score_addition = proto.Field(proto.UINT32, number=19)
    left_goal_int = proto.Field(proto.UINT64, number=20)
    right_goal_int = proto.Field(proto.UINT64, number=21)


class MatchAgainstScoreMessage(proto.Message):
    common = proto.Field(Common, number=1)
    against = proto.Field(Against, number=2)
    match_status = proto.Field(proto.UINT32, number=3)
    display_status = proto.Field(proto.UINT32, number=4)


class EpisodeChatMessage(proto.Message):
    common = proto.Field(Message, number=1)
    user = proto.Field(User, number=2)
    content = proto.Field(proto.STRING, number=3)
    visible_to_sende = proto.Field(proto.BOOL, number=4)
    gift_image = proto.Field(Image, number=7)
    agree_msg_id = proto.Field(proto.UINT64, number=8)
    color_value_list = proto.RepeatedField(proto.STRING, number=9)


# ── Misc ──

class Kk(proto.Message):
    k = proto.Field(proto.UINT32, number=14)


class ExtList(proto.Message):
    key = proto.Field(proto.STRING, number=1)
    value = proto.Field(proto.STRING, number=2)


class RspF(proto.Message):
    q1 = proto.Field(proto.UINT64, number=1)
    q3 = proto.Field(proto.UINT64, number=3)
    q4 = proto.Field(proto.STRING, number=4)
    q5 = proto.Field(proto.UINT64, number=5)


class Rsp(proto.Message):
    a = proto.Field(proto.INT32, number=1)
    b = proto.Field(proto.INT32, number=2)
    c = proto.Field(proto.INT32, number=3)
    d = proto.Field(proto.STRING, number=4)
    e = proto.Field(proto.INT32, number=5)
    f = proto.Field(RspF, number=6)
    g = proto.Field(proto.STRING, number=7)
    h = proto.Field(proto.UINT64, number=10)
    i = proto.Field(proto.UINT64, number=11)
    j = proto.Field(proto.UINT64, number=13)


class SendMessageBody(proto.Message):
    conversation_id = proto.Field(proto.STRING, number=1)
    conversation_type = proto.Field(proto.UINT32, number=2)
    conversation_short_id = proto.Field(proto.UINT64, number=3)
    content = proto.Field(proto.STRING, number=4)
    ext = proto.RepeatedField(ExtList, number=5)
    message_type = proto.Field(proto.UINT32, number=6)
    ticket = proto.Field(proto.STRING, number=7)
    client_message_id = proto.Field(proto.STRING, number=8)


class PreMessage(proto.Message):
    cmd = proto.Field(proto.UINT32, number=1)
    sequence_id = proto.Field(proto.UINT32, number=2)
    sdk_version = proto.Field(proto.STRING, number=3)
    token = proto.Field(proto.STRING, number=4)
    refer = proto.Field(proto.UINT32, number=5)
    inbox_type = proto.Field(proto.UINT32, number=6)
    build_number = proto.Field(proto.STRING, number=7)
    send_message_body = proto.Field(SendMessageBody, number=8)
    aa = proto.Field(proto.STRING, number=9)
    device_platform = proto.Field(proto.STRING, number=11)
    headers = proto.RepeatedField(HeadersList, number=15)
    auth_type = proto.Field(proto.UINT32, number=18)
    biz = proto.Field(proto.STRING, number=21)
    access = proto.Field(proto.STRING, number=22)
