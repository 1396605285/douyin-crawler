#!/usr/bin/env python3
"""抖音直播间弹幕数据采集器 - 单元测试"""

import hashlib
import json
import os
import sys
import time
import unittest

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))


class TestToolFunctions(unittest.TestCase):
    """工具函数测试"""

    def test_generate_user_unique_id(self):
        from live_crawler import _generate_user_unique_id
        uid = _generate_user_unique_id()
        self.assertEqual(len(uid), 19)
        self.assertTrue(uid.isdigit())
        # 每次应该不同
        uid2 = _generate_user_unique_id()
        self.assertNotEqual(uid, uid2)

    def test_generate_ms_token(self):
        from live_crawler import _generate_ms_token
        token = _generate_ms_token()
        self.assertEqual(len(token), 182)
        # 默认字符集
        allowed = set('abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-_')
        self.assertTrue(all(c in allowed for c in token))

    def test_extract_ua_version(self):
        from live_crawler import _extract_ua_version
        self.assertEqual(
            _extract_ua_version('Mozilla/5.0 Chrome/121.0.0.0 Safari/537.36'),
            'Chrome/121.0.0.0'
        )
        self.assertEqual(
            _extract_ua_version('Mozilla/5.0 Firefox/121.0'),
            'Chrome/120.0.0.0'  # fallback
        )

    def test_safe_time(self):
        from live_crawler import _safe_time
        # 正常时间戳
        self.assertEqual(_safe_time(1700000000), time.strftime('%H:%M:%S', time.localtime(1700000000)))
        # 边界值
        self.assertEqual(_safe_time(0), '')
        self.assertEqual(_safe_time(None), '')
        self.assertEqual(_safe_time(9999999999), '')  # 超出范围


class TestGenerateSignature(unittest.TestCase):
    """签名生成测试"""

    def test_signature_basic(self):
        from live_crawler import generate_signature
        wss = 'wss://webcast100-ws-web-lq.douyin.com/webcast/im/push/v2/?app_name=douyin_web&version_code=180800&room_id=7627649174883928842&live_id=1'
        sig = generate_signature(wss)
        self.assertIsInstance(sig, str)
        self.assertEqual(len(sig), 16)

    def test_signature_different_inputs(self):
        from live_crawler import generate_signature
        wss1 = 'wss://x.com/?room_id=111&live_id=1'
        wss2 = 'wss://x.com/?room_id=222&live_id=1'
        sig1 = generate_signature(wss1)
        sig2 = generate_signature(wss2)
        self.assertNotEqual(sig1, sig2)


class TestProtobufTypes(unittest.TestCase):
    """Protobuf 类型完整性测试"""

    def test_all_handler_types_exist(self):
        from live_messages import (
            ChatMessage, GiftMessage, LikeMessage, MemberMessage,
            SocialMessage, RoomUserSeqMessage, FansclubMessage,
            ControlMessage, EmojiChatMessage, RoomStatsMessage,
            RoomMessage, RoomRankMessage, RoomStreamAdaptationMessage,
            PushFrame, Response, Message, Common, User,
            GiftStruct, PayGrade, FansClub, FansClubData,
        )
        import proto
        for cls in [ChatMessage, GiftMessage, LikeMessage, MemberMessage,
                     PushFrame, Response, User]:
            self.assertTrue(issubclass(cls, proto.Message))

    def test_pushframe_roundtrip(self):
        from live_messages import PushFrame
        frame = PushFrame(seq_id=42, log_id=12345, payload_type='hb')
        data = frame._pb.SerializeToString()
        pb = PushFrame.meta.pb()
        pb.ParseFromString(data)
        parsed = PushFrame.wrap(pb)
        self.assertEqual(parsed.seq_id, 42)
        self.assertEqual(parsed.log_id, 12345)
        self.assertEqual(parsed.payload_type, 'hb')

    def test_chat_message(self):
        from live_messages import ChatMessage, Common, User
        msg = ChatMessage(
            common=Common(msg_id=1, room_id=100),
            user=User(id=999, nick_name='test'),
            content='hello'
        )
        data = msg._pb.SerializeToString()
        pb = ChatMessage.meta.pb()
        pb.ParseFromString(data)
        parsed = ChatMessage.wrap(pb)
        self.assertEqual(parsed.content, 'hello')
        self.assertEqual(parsed.user.nick_name, 'test')


class TestConfig(unittest.TestCase):
    """配置加载测试"""

    def test_load_missing_config(self):
        from live_crawler import DouyinLiveWebFetcher
        # 不应该崩溃，应该使用默认配置
        room = DouyinLiveWebFetcher('123', config_file='nonexistent.json')
        self.assertIsInstance(room.config, dict)
        self.assertIn('output', room.config)

    def test_load_valid_config(self):
        from live_crawler import DouyinLiveWebFetcher
        config_path = os.path.join(os.path.dirname(__file__), 'config.json')
        if os.path.exists(config_path):
            room = DouyinLiveWebFetcher('123', config_file=config_path)
            self.assertIn('network', room.config)
            self.assertIn('output', room.config)


class TestThroughputCounter(unittest.TestCase):
    """吞吐量统计测试"""

    def test_counter(self):
        from live_crawler import ThroughputCounter
        c = ThroughputCounter()
        c.inc('chat')
        c.inc('chat')
        c.inc('gift')
        # 等待超过 0.1s 才能出报告
        time.sleep(0.15)
        report = c.report()
        self.assertIn('总计:3', report)
        self.assertIn('chat:2', report)
        self.assertIn('gift:1', report)


if __name__ == '__main__':
    unittest.main()
