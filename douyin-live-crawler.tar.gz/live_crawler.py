#!/usr/bin/python
# coding:utf-8
"""抖音直播间弹幕数据采集器 - 核心模块"""

import csv
import gzip
import hashlib
import json
import logging
import logging.handlers
import os
import random
import re
import string
import threading
import time
import urllib.parse
from collections import deque
from socket import SOL_SOCKET, SO_RCVBUF

import subprocess

import requests
from requests.adapters import HTTPAdapter
import websocket

from live_messages import *


# proto-plus 反序列化快捷方式
def _parse(cls, data):
    """proto-plus 反序列化，替代 betterproto .parse()"""
    pb = cls.meta.pb()
    pb.ParseFromString(data)
    return cls.wrap(pb)


# ═══════════════════════════════════════════════════════════════════════
# 常量
# ═══════════════════════════════════════════════════════════════════════

_SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
_LOG_FILE = os.path.join(_SCRIPT_DIR, 'douyin_live.log')

_USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15",
]


# ═══════════════════════════════════════════════════════════════════════
# 日志（非阻塞队列模式，避免高流量下卡住 WebSocket 回调）
# ═══════════════════════════════════════════════════════════════════════

class _QueueHandler(logging.Handler):
    """将日志记录放入 deque，由后台线程异步写出"""
    def __init__(self):
        super().__init__()
        self._buf = deque(maxlen=50_000)
        self._handlers: list[logging.Handler] = []
        self._stop = threading.Event()
        self._dropped = 0
        self._thread = None  # 延迟启动

    def _ensure_started(self):
        if self._thread is None:
            self._thread = threading.Thread(target=self._drain_loop, daemon=True, name='log-drain')
            self._thread.start()

    def add_handler(self, h):
        self._handlers.append(h)

    def emit(self, record):
        self._ensure_started()
        if len(self._buf) >= self._buf.maxlen - 1:
            self._dropped += 1
        self._buf.append(record)

    def _drain_loop(self):
        while not self._stop.wait(timeout=0.5):
            self._drain()
        self._drain()

    def _drain(self):
        batch = []
        while self._buf and len(batch) < 2000:
            batch.append(self._buf.popleft())
        for record in batch:
            for h in self._handlers:
                try:
                    h.emit(record)
                except Exception:
                    pass
        if self._dropped > 0:
            import sys
            sys.stderr.write(f"[logger] 日志队列溢出，已丢弃 {self._dropped} 条\n")
            self._dropped = 0

    def close(self):
        self._stop.set()
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=3)
        self._drain()
        for h in self._handlers:
            try:
                h.close()
            except Exception:
                pass
        super().close()


_logger = logging.getLogger(__name__)
_logger.setLevel(logging.INFO)

_fmt = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

_queue_handler = _QueueHandler()

_stream = logging.StreamHandler()
_stream.setFormatter(_fmt)
_queue_handler.add_handler(_stream)

_file = logging.handlers.RotatingFileHandler(
    _LOG_FILE, encoding='utf-8',
    maxBytes=50 * 1024 * 1024,  # 50MB
    backupCount=3
)
_file.setFormatter(_fmt)
_queue_handler.add_handler(_file)

_logger.addHandler(_queue_handler)
_logger.propagate = False

logger = _logger


# ═══════════════════════════════════════════════════════════════════════
# JS 签名（subprocess 隔离执行，消除 PyExecJS 依赖）
# ═══════════════════════════════════════════════════════════════════════

_SIGN_SCRIPT = os.path.join(_SCRIPT_DIR, 'sign_runner.js')

# 确保 sign_runner.js 存在（首次运行自动生成）
if not os.path.exists(_SIGN_SCRIPT):
    _sign_runner_code = (
        'const fs = require("fs");\n'
        'eval(fs.readFileSync(__dirname + "/sign.js", "utf8"));\n'
        'const input = fs.readFileSync("/dev/stdin", "utf8").trim();\n'
        'try {\n'
        '    process.stdout.write(crawler({"X-MS-STUB": input})["X-Bogus"] || "");\n'
        '} catch(e) {\n'
        '    process.stderr.write("sign error: " + e.message);\n'
        '    process.exit(1);\n'
        '}\n'
        'process.exit(0);\n'
    )
    with open(_SIGN_SCRIPT, 'w', encoding='utf-8') as f:
        f.write(_sign_runner_code)


# ═══════════════════════════════════════════════════════════════════════
# 工具函数
# ═══════════════════════════════════════════════════════════════════════

def _generate_user_unique_id():
    return ''.join(str(random.randint(0, 9)) for _ in range(19))


def _generate_ms_token(length=182):
    base = string.ascii_letters + string.digits + '-_'
    return ''.join(random.choice(base) for _ in range(length))


def _extract_ua_version(ua: str) -> str:
    m = re.search(r'Chrome/(\d+\.\d+\.\d+\.\d+)', ua)
    return f"Chrome/{m.group(1)}" if m else "Chrome/120.0.0.0"


def generate_signature(wss, script_file='sign.js'):
    params = ("live_id,aid,version_code,webcast_sdk_version,"
              "room_id,sub_room_id,sub_channel_id,did_rule,"
              "user_unique_id,device_platform,device_type,ac,"
              "identity").split(',')
    wss_params = urllib.parse.urlparse(wss).query.split('&')
    wss_maps = {i.split('=', 1)[0]: i.split('=', 1)[-1] for i in wss_params}
    tpl_params = [f"{i}={wss_maps.get(i, '')}" for i in params]
    param = ','.join(tpl_params)
    md5_param = hashlib.md5(param.encode()).hexdigest()
    r = subprocess.run(
        ['node', _SIGN_SCRIPT],
        input=md5_param.encode(),
        stdout=subprocess.PIPE, stderr=subprocess.PIPE,
        timeout=10
    )
    if r.returncode != 0:
        raise RuntimeError(f"JS签名失败: {r.stderr.decode().strip()}")
    return r.stdout.decode().strip()


def _fmt_fans_club(user):
    try:
        club = user.fans_club.data
        if club and club.club_name:
            return f"[粉丝团:{club.club_name} Lv{club.level}]"
        elif club and club.level > 0:
            return f"[粉丝团 Lv{club.level}]"
    except (AttributeError, TypeError):
        pass
    return ''


def _fmt_grade(user):
    try:
        if user.pay_grade and user.pay_grade.level > 0:
            return f"[等级{user.pay_grade.level}]"
    except (AttributeError, TypeError):
        pass
    return ''


def _safe_time(ts):
    if ts and 0 < ts < 4102444800:
        return time.strftime('%H:%M:%S', time.localtime(ts))
    return ''


def _http_get_with_retry(session, url, max_retries=3, timeout=15, **kwargs):
    """
    带指数退避 + DNS 重试的 HTTP GET
    超时后自动加大 timeout（封顶 60s），最多重试 max_retries 次
    """
    last_exc = None
    for attempt in range(max_retries):
        try:
            resp = session.get(url, timeout=timeout, **kwargs)
            resp.raise_for_status()
            return resp
        except requests.exceptions.ConnectionError as e:
            last_exc = e
            wait = min(2 ** attempt + random.uniform(0, 1), 10)
            logger.warning(f"连接失败 (尝试 {attempt+1}/{max_retries}): {e}, {wait:.1f}s 后重试")
            time.sleep(wait)
        except requests.exceptions.Timeout as e:
            last_exc = e
            timeout = min(timeout * 1.5, 60)
            wait = min(2 ** attempt + random.uniform(0, 1), 10)
            logger.warning(f"请求超时 (尝试 {attempt+1}/{max_retries}), 下次timeout={timeout:.0f}s, {wait:.1f}s 后重试")
            time.sleep(wait)
        except requests.RequestException as e:
            last_exc = e
            if attempt < max_retries - 1:
                time.sleep(min(2 ** attempt, 10))
            else:
                raise
    raise last_exc


# ═══════════════════════════════════════════════════════════════════════
# 吞吐量统计
# ═══════════════════════════════════════════════════════════════════════

class ThroughputCounter:
    __slots__ = ('_count', '_start', '_by_type')

    def __init__(self):
        self._count = 0
        self._start = time.monotonic()
        self._by_type = {}

    def inc(self, msg_type: str = ''):
        self._count += 1
        if msg_type:
            self._by_type[msg_type] = self._by_type.get(msg_type, 0) + 1

    def report(self) -> str:
        elapsed = time.monotonic() - self._start
        if elapsed < 0.1:
            return "统计中..."
        rate = self._count / elapsed
        parts = [f"总计:{self._count}", f"{rate:.1f}msg/s"]
        if self._by_type:
            top = sorted(self._by_type.items(), key=lambda x: -x[1])[:5]
            parts.append("[" + ", ".join(f"{k}:{v}" for k, v in top) + "]")
        return " | ".join(parts)


# ═══════════════════════════════════════════════════════════════════════
# 批量数据记录器
# ═══════════════════════════════════════════════════════════════════════

class DataRecorder:

    _CSV_FIELDS = {
        'chat':     ['time', 'user_id', 'user_name', 'content', 'grade', 'fans_club'],
        'gift':     ['time', 'user_id', 'user_name', 'gift_name', 'gift_count', 'diamond_total', 'grade', 'fans_club'],
        'like':     ['time', 'user_id', 'user_name', 'count', 'total', 'grade', 'fans_club'],
        'member':   ['time', 'user_id', 'user_name', 'gender', 'grade', 'fans_club', 'member_count'],
        'social':   ['time', 'user_id', 'user_name', 'action', 'grade', 'fans_club'],
        'fansclub': ['time', 'user_id', 'user_name', 'type', 'content', 'grade', 'fans_club'],
        'emoji':    ['time', 'user_id', 'user_name', 'emoji_id', 'content', 'grade', 'fans_club'],
        'stats':    ['time', 'current', 'total_pv', 'total_user', 'online_anchor'],
        'roomstats':['time', 'detail', 'total'],
        'room':     ['time', 'is_top', 'room_id', 'content', 'biz_scene'],
        'rank':     ['time', 'ranks'],
        'control':  ['time', 'status'],
    }

    def __init__(self, live_id: str, config: dict):
        self.live_id = live_id
        output_cfg = config.get('output', {})
        self._fmt = output_cfg.get('file_format', 'none')
        self._enable_outputs = config.get('output', {})
        self._dir = output_cfg.get('file_dir', os.path.join(_SCRIPT_DIR, 'data'))

        self._json_buf: deque = deque(maxlen=200_000)
        self._csv_bufs: dict[str, deque] = {}
        self._csv_writers = {}
        self._csv_fps = {}
        self._json_fp = None
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._flush_thread = None
        self._dropped = 0  # 被丢弃的消息计数

        if self._fmt != 'none':
            ts = time.strftime('%Y%m%d_%H%M%S')
            ym = time.strftime('%Y%m')
            self._dir = os.path.join(self._dir, live_id, ym)
            os.makedirs(self._dir, exist_ok=True)

            if self._fmt in ('csv', 'both'):
                for msg_type, fields in self._CSV_FIELDS.items():
                    if not self._enable_outputs.get(msg_type, True):
                        continue
                    path = os.path.join(self._dir, f"{ts}_{msg_type}.csv")
                    fp = open(path, 'w', newline='', encoding='utf-8-sig')
                    writer = csv.DictWriter(fp, fieldnames=fields)
                    writer.writeheader()
                    self._csv_fps[msg_type] = fp
                    self._csv_writers[msg_type] = writer
                    self._csv_bufs[msg_type] = deque(maxlen=100_000)

            if self._fmt in ('json', 'both'):
                self._json_fp = open(os.path.join(self._dir, f"{ts}.jsonl"), 'a', encoding='utf-8')

            self._flush_thread = threading.Thread(target=self._bg_flush_loop, daemon=True, name='recorder-flush')
            self._flush_thread.start()

    def record(self, msg_type: str, data: dict):
        if self._fmt in ('csv', 'both'):
            buf = self._csv_bufs.get(msg_type)
            if buf is not None:
                if len(buf) >= buf.maxlen - 1:
                    self._dropped += 1
                buf.append(data)
        if self._fmt in ('json', 'both'):
            if len(self._json_buf) >= self._json_buf.maxlen - 1:
                self._dropped += 1
            self._json_buf.append((msg_type, data))

    def _bg_flush_loop(self):
        while not self._stop.wait(timeout=2.0):
            self._do_flush()
            if self._dropped > 0:
                logger.warning(f"⚠️ 数据记录缓冲区溢出，已丢弃 {self._dropped} 条消息（考虑增大 deque 或开启 file_format）")
                self._dropped = 0
        self._do_flush()

    def _do_flush(self):
        with self._lock:
            for msg_type, buf in self._csv_bufs.items():
                writer = self._csv_writers.get(msg_type)
                fp = self._csv_fps.get(msg_type)
                if not writer or not fp:
                    continue
                count = 0
                while buf and count < 5000:
                    try:
                        writer.writerow(buf.popleft())
                        count += 1
                    except Exception:
                        break
                if count:
                    fp.flush()

            if self._json_fp and self._json_buf:
                lines = []
                while self._json_buf and len(lines) < 5000:
                    msg_type, data = self._json_buf.popleft()
                    lines.append(json.dumps({'type': msg_type, 'ts': time.time(), 'data': data}, ensure_ascii=False))
                if lines:
                    self._json_fp.write('\n'.join(lines) + '\n')
                    self._json_fp.flush()

    def close(self):
        self._stop.set()
        if self._flush_thread and self._flush_thread.is_alive():
            self._flush_thread.join(timeout=3)
        self._do_flush()
        for fp in self._csv_fps.values():
            try:
                fp.close()
            except Exception:
                pass
        if self._json_fp:
            try:
                self._json_fp.close()
            except Exception:
                pass
        self._csv_fps.clear()
        self._csv_writers.clear()
        logger.info("数据记录器已关闭")


# ═══════════════════════════════════════════════════════════════════════
# 主采集器
# ═══════════════════════════════════════════════════════════════════════

class DouyinLiveWebFetcher:

    _HANDLERS = {}

    def __init__(self, live_id, config_file='config.json'):
        self.config = self._load_config(config_file)

        # 日志级别
        log_level = self.config.get('log_level', 'INFO').upper()
        _logger.setLevel(getattr(logging, log_level, logging.INFO))

        # 日志开关
        if not self.config.get('log_enabled', True):
            _logger.setLevel(logging.CRITICAL + 1)  # 高于所有级别，全部静默

        self._enable_outputs = self.config.get('output', {})

        # UA（一次选定，全局一致）
        self._ua = random.choice(_USER_AGENTS)
        self._ua_version = _extract_ua_version(self._ua)
        self._user_unique_id = _generate_user_unique_id()

        # ── 网络超时参数（全部可配置，适配弱网）────────────────────
        net_cfg = self.config.get('network', {})
        self._http_timeout       = net_cfg.get('http_timeout', 15)         # HTTP 请求超时
        self._ws_connect_timeout = net_cfg.get('ws_connect_timeout', 30)   # WS 握手超时
        self._silence_timeout    = net_cfg.get('silence_timeout', 60)      # 看门狗静默阈值
        self._heartbeat_interval = net_cfg.get('heartbeat_interval', 10)   # 心跳间隔
        self._proxy              = net_cfg.get('proxy', None)              # 代理
        self._rcvbuf             = net_cfg.get('rcvbuf_kb', 256) * 1024    # 接收缓冲区

        # HTTP Session（调大连接池 + 超时 + 代理）
        self.session = requests.Session()
        adapter = HTTPAdapter(pool_connections=10, pool_maxsize=20, max_retries=2)
        self.session.mount('https://', adapter)
        self.session.mount('http://', adapter)
        self.session.headers.update({'User-Agent': self._ua})
        if self._proxy:
            self.session.proxies.update(self._proxy)
            logger.info(f"使用代理: {self._proxy}")

        self.live_id = live_id
        self.host = "https://www.douyin.com/"
        self.live_url = "https://live.douyin.com/"

        # 连接状态
        self.ws = None
        self._connected_event = threading.Event()
        self._stop_event = threading.Event()

        # 心跳
        self._heartbeat_thread = None

        # 健康检测
        self._last_msg_time = 0.0
        self._watchdog_thread = None

        # 吞吐量
        self._counter = ThroughputCounter()

        # 数据记录器
        self._recorder = DataRecorder(live_id, self.config)

        # 统计定时打印
        self._stats_thread = None
        self._stats_interval = self.config.get('stats_interval', 60)

        # 连接重试计数（由 connectWebSocket 内部管理）
        self._reconnect_count = 0

    @staticmethod
    def _load_config(config_file):
        if not os.path.isabs(config_file):
            config_file = os.path.join(_SCRIPT_DIR, config_file)
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError) as e:
            logger.warning(f"配置加载失败({e})，使用默认配置")
            return {'output': {}}

    # ── 启动 / 停止 ──

    def start(self):
        logger.info(f"启动采集: live_id={self.live_id}")
        logger.info(f"UA={self._ua}")
        logger.info(f"user_unique_id={self._user_unique_id}")
        logger.info(f"网络配置: http_timeout={self._http_timeout}s, "
                     f"ws_connect_timeout={self._ws_connect_timeout}s, "
                     f"silence_timeout={self._silence_timeout}s, "
                     f"heartbeat_interval={self._heartbeat_interval}s, "
                     f"rcvbuf={self._rcvbuf//1024}KB"
                     f"{', proxy=on' if self._proxy else ''}")
        self._connectWebSocket()

    def stop(self):
        if self._stop_event.is_set():
            return  # 防止重复调用
        logger.info("停止采集")
        self._stop_event.set()
        self._connected_event.clear()
        if self.ws:
            try:
                self.ws.close()
            except Exception:
                pass
        for t in (self._heartbeat_thread, self._watchdog_thread, self._stats_thread):
            if t and t.is_alive():
                t.join(timeout=3)
        logger.info(f"最终统计: {self._counter.report()}")
        self._recorder.close()

    # ── 属性 ──

    @property
    def ttwid(self):
        if hasattr(self, '_ttwid') and self._ttwid:
            return self._ttwid
        resp = _http_get_with_retry(self.session, self.live_url, timeout=self._http_timeout)
        self._ttwid = resp.cookies.get('ttwid')
        return self._ttwid

    @property
    def room_id(self):
        if hasattr(self, '_room_id') and self._room_id:
            return self._room_id

        url = f"{self.live_url}{self.live_id}"
        headers = {
            "User-Agent": self._ua,
            "cookie": f"ttwid={self.ttwid}&msToken={_generate_ms_token()}",
        }
        resp = _http_get_with_retry(self.session, url, headers=headers, timeout=self._http_timeout)

        for pattern in (
            r'"roomId"\s*:\s*"?(\d+)"?',
            r'roomId\\":\\"(\d+)\\"',
            r'roomId["\\:=]+\s*"?(\d{10,20})"?',
        ):
            m = re.search(pattern, resp.text)
            if m:
                self._room_id = m.group(1)
                logger.info(f"获取 room_id: {self._room_id}")
                return self._room_id

        raise ValueError(f"无法找到 roomId，响应前 500 字符: {resp.text[:500]}")

    # ── WebSocket ──

    def _connectWebSocket(self):
        max_reconnects = self.config.get('max_reconnects', 0)  # 0 = 无限重连
        base_delay = self.config.get('reconnect_base_delay', 2)
        max_delay = self.config.get('reconnect_max_delay', 120)
        self._reconnect_count = 0

        while not self._stop_event.is_set():
            try:
                logger.info(f"连接 WebSocket (第 {self._reconnect_count + 1} 次)")
                wss = self._buildWebSocketURL()
                signature = generate_signature(wss, script_file='sign.js')
                wss += f"&signature={signature}"

                headers = {
                    "cookie": f"ttwid={self.ttwid}",
                    "user-agent": self._ua,
                }

                self.ws = websocket.WebSocketApp(
                    wss,
                    header=headers,
                    on_open=self._wsOnOpen,
                    on_message=self._wsOnMessage,
                    on_error=self._wsOnError,
                    on_close=self._wsOnClose,
                )

                self.ws.run_forever(
                    sockopt=(
                        (SOL_SOCKET, SO_RCVBUF, self._rcvbuf),
                    ),
                    # 不用内置 ping，由 _heartbeat_loop 自己管理
                    ping_interval=0,
                    # 底层 socket 连接/读写超时
                    http_proxy_timeout=self._ws_connect_timeout,
                )

            except Exception as e:
                logger.error(f"WebSocket 异常: {e}")

            self._connected_event.clear()

            if self._stop_event.is_set():
                break

            self._reconnect_count += 1
            if max_reconnects > 0 and self._reconnect_count >= max_reconnects:
                logger.error(f"达到最大重连次数 ({max_reconnects})，停止")
                break

            delay = min(base_delay * (2 ** min(self._reconnect_count - 1, 6)), max_delay)
            delay += random.uniform(0, 2)  # 抖动，避免雪崩
            logger.warning(f"断开，{delay:.1f}s 后重连 ({self._reconnect_count}"
                           f"{'/' + str(max_reconnects) if max_reconnects > 0 else ''})")
            self._stop_event.wait(timeout=delay)

        logger.info("采集主循环退出")

    def _buildWebSocketURL(self):
        ts = int(time.time() * 1000)
        room_id = self.room_id
        uid = self._user_unique_id

        return (
            f"wss://webcast100-ws-web-lq.douyin.com/webcast/im/push/v2/"
            f"?app_name=douyin_web"
            f"&version_code=180800"
            f"&webcast_sdk_version=1.0.14-beta.0"
            f"&update_version_code=1.0.14-beta.0"
            f"&compress=gzip"
            f"&device_platform=web"
            f"&cookie_enabled=true"
            f"&screen_width=1536&screen_height=864"
            f"&browser_language=zh-CN&browser_platform=Win32"
            f"&browser_name=Mozilla"
            f"&browser_version={urllib.parse.quote(self._ua_version, safe='')}"
            f"&browser_online=true&tz_name=Asia/Shanghai"
            f"&internal_ext=internal_src:dim|wss_push_room_id:{room_id}"
            f"|wss_push_did:{uid}"
            f"|first_req_ms:{ts}|fetch_time:{ts + random.randint(1, 100)}"
            f"|seq:1|wss_info:0-{ts}-0-0"
            f"|wrds_v:{random.randint(10**17, 10**18 - 1)}"
            f"&host=https://live.douyin.com"
            f"&aid=6383&live_id=1&did_rule=3"
            f"&endpoint=live_pc&support_wrds=1"
            f"&user_unique_id={uid}"
            f"&im_path=/webcast/im/fetch/"
            f"&identity=audience"
            f"&need_persist_msg_count=15"
            f"&room_id={room_id}"
            f"&heartbeatDuration=0"
        )

    # ── 心跳（自定义业务层心跳，独立于 ws 底层 ping/pong）──

    def _heartbeat_loop(self):
        interval = max(self._heartbeat_interval, 3)
        while not self._stop_event.is_set():
            try:
                if self._connected_event.is_set():
                    self.ws.send(
                        PushFrame(payload_type="hb")._pb.SerializeToString(),
                        websocket.ABNF.OPCODE_PING,
                    )
            except Exception:
                break
            self._stop_event.wait(timeout=interval + random.uniform(0, 2))

    # ── 看门狗（自适应静默阈值）──

    def _watchdog_loop(self):
        check_interval = min(self._silence_timeout // 3, 10)
        check_interval = max(check_interval, 3)

        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=check_interval)
            if not self._connected_event.is_set():
                continue
            if self._last_msg_time <= 0:
                continue
            silence = time.time() - self._last_msg_time
            if silence > self._silence_timeout:
                logger.warning(f"看门狗: {silence:.0f}s 无消息 (阈值={self._silence_timeout}s)，触发重连")
                try:
                    self.ws.close()
                except Exception:
                    pass
                break

    # ── 统计定时打印 ──

    def _stats_loop(self):
        while not self._stop_event.is_set():
            self._stop_event.wait(timeout=self._stats_interval)
            if self._connected_event.is_set():
                logger.info(f"[吞吐统计] {self._counter.report()}")

    # ── WebSocket 回调 ──

    def _wsOnOpen(self, ws):
        logger.info("WebSocket 连接成功")
        self._connected_event.set()
        self._last_msg_time = time.time()

        self._heartbeat_thread = threading.Thread(target=self._heartbeat_loop, daemon=True, name='heartbeat')
        self._heartbeat_thread.start()

        self._watchdog_thread = threading.Thread(target=self._watchdog_loop, daemon=True, name='watchdog')
        self._watchdog_thread.start()

        self._stats_thread = threading.Thread(target=self._stats_loop, daemon=True, name='stats')
        self._stats_thread.start()

    def _wsOnMessage(self, ws, message):
        self._last_msg_time = time.time()

        try:
            package = _parse(PushFrame, message)
        except Exception as e:
            logger.debug(f"解析 PushFrame 失败: {e}")
            return

        # gzip 解压（弱网下可能拿到损坏的包）
        try:
            decompressed = gzip.decompress(package.payload)
        except Exception as e:
            logger.warning(f"gzip 解压失败 (可能是丢包/乱序): {e}")
            return

        try:
            response = _parse(Response, decompressed)
        except Exception as e:
            logger.warning(f"解析 Response 失败: {e}")
            return

        # ACK
        if response.need_ack:
            try:
                ack = PushFrame(
                    log_id=package.log_id,
                    payload_type='ack',
                    payload=response.internal_ext.encode('utf-8')
                )._pb.SerializeToString()
                ws.send(ack, websocket.ABNF.OPCODE_BINARY)
            except Exception as e:
                logger.error(f"ACK 发送失败: {e}")

        # 消息分发
        for msg in response.messages_list:
            handler = self._HANDLERS.get(msg.method)
            if handler:
                try:
                    handler(self, msg.payload)
                    self._counter.inc(msg.method.replace('Webcast', '').replace('Message', '').lower())
                except Exception as e:
                    logger.error(f"处理 {msg.method} 失败: {e}")
            else:
                # 已知但未详细解析的消息类型（debug 级别，不计入 unknown）
                _low_value_types = {
                    'WebcastRanklistHourEntranceMessage',
                    'WebcastRoomDataSyncMessage',
                    'WebcastChatLikeMessage',
                    'WebcastResidentGuestMessage',
                    'WebcastLowPcuGuideMessage',
                    'WebcastCommonDotMessage',
                    'WebcastGiftUpdateMessage',
                    'WebcastInRoomBannerMessage',
                    'WebcastNotifyEffectMessage',
                    'WebcastHotRoomMessage',
                    'WebcastRoomStreamAdaptationMessage',
                }
                if msg.method in _low_value_types:
                    logger.debug(f"低频消息: {msg.method}")
                    self._counter.inc(msg.method.replace('Webcast', '').replace('Message', '').lower())
                else:
                    self._counter.inc('unknown')
                    logger.debug(f"未处理的消息类型: {msg.method}")

    def _wsOnError(self, ws, error):
        logger.error(f"WebSocket 错误: {error}")
        self._connected_event.clear()

    def _wsOnClose(self, ws, code, msg):
        logger.info(f"WebSocket 关闭 (code={code})")
        self._connected_event.clear()

    # ── 消息解析 ──

    def _parseChatMsg(self, payload):
        if not self._enable_outputs.get('chat', True):
            return
        msg = _parse(ChatMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        logger.info(f"聊天消息 - 用户:{user.nick_name}[{uid}] 内容:{msg.content}")
        self._recorder.record('chat', {
            'time': _safe_time(msg.common.create_time if msg.common else 0) or time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name, 'content': msg.content,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
        })

    def _parseGiftMsg(self, payload):
        if not self._enable_outputs.get('gift', True):
            return
        msg = _parse(GiftMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        gift = msg.gift
        cnt = msg.combo_count or msg.total_count or msg.repeat_count or 1
        diamond_total = gift.diamond_count * cnt
        diamond_info = f" (≈{diamond_total}抖币)" if diamond_total > 0 else ""
        logger.info(f"礼物消息 - 用户:{user.nick_name}[{uid}] 礼物:{gift.name} x{cnt}{diamond_info}")
        self._recorder.record('gift', {
            'time': time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name, 'gift_name': gift.name,
            'gift_count': cnt, 'diamond_total': diamond_total,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
        })

    def _parseLikeMsg(self, payload):
        if not self._enable_outputs.get('like', True):
            return
        msg = _parse(LikeMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        logger.info(f"点赞消息 - 用户:{user.nick_name}[{uid}] 点赞:{msg.count}个, 累计{msg.total}赞")
        self._recorder.record('like', {
            'time': time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name,
            'count': msg.count, 'total': msg.total,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
        })

    def _parseMemberMsg(self, payload):
        if not self._enable_outputs.get('member', True):
            return
        msg = _parse(MemberMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        gender = {0: "未知", 1: "男", 2: "女"}.get(user.gender, "未知")
        extras = f" (直播间人数:{msg.member_count})" if msg.member_count else ""
        logger.info(f"进场消息 - 用户:{user.nick_name}[{uid}][{gender}] 进入了直播间{extras}")
        self._recorder.record('member', {
            'time': time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name, 'gender': gender,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
            'member_count': msg.member_count,
        })

    def _parseSocialMsg(self, payload):
        if not self._enable_outputs.get('social', True):
            return
        msg = _parse(SocialMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        action = {1: "关注了主播", 2: "分享了直播间"}.get(msg.action, "互动")
        follow = f"(第{msg.follow_count}个关注)" if msg.follow_count else ""
        logger.info(f"关注/分享消息 - 用户:{user.nick_name}[{uid}] {action} {follow}")
        self._recorder.record('social', {
            'time': time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name, 'action': action,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
        })

    def _parseRoomUserSeqMsg(self, payload):
        if not self._enable_outputs.get('stats', True):
            return
        msg = _parse(RoomUserSeqMessage, payload)
        parts = [f"当前: {msg.total}"]
        if msg.total_pv_for_anchor:
            parts.append(f"累计: {msg.total_pv_for_anchor}")
        if msg.total_user_str:
            parts.append(f"累计用户: {msg.total_user_str}")
        if msg.online_user_for_anchor:
            parts.append(f"主播端在线: {msg.online_user_for_anchor}")
        logger.info(f"统计消息 - {', '.join(parts)}")
        self._recorder.record('stats', {
            'time': time.strftime('%H:%M:%S'),
            'current': msg.total,
            'total_pv': msg.total_pv_for_anchor or '',
            'total_user': msg.total_user_str or '',
            'online_anchor': msg.online_user_for_anchor or '',
        })

    def _parseFansclubMsg(self, payload):
        if not self._enable_outputs.get('fansclub', True):
            return
        msg = _parse(FansclubMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        t = {1: "升级", 2: "加入"}.get(msg.type, "变动")
        logger.info(f"粉丝团消息 - 用户:{user.nick_name}[{uid}] {t}: {msg.content}")
        self._recorder.record('fansclub', {
            'time': time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name,
            'type': t, 'content': msg.content,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
        })

    def _parseEmojiChatMsg(self, payload):
        if not self._enable_outputs.get('emoji', True):
            return
        msg = _parse(EmojiChatMessage, payload)
        user = msg.user
        uid = user.id_str or str(user.id)
        content = msg.default_content or f"[表情{msg.emoji_id}]"
        logger.info(f"表情消息 - 用户:{user.nick_name}[{uid}]: {content}")
        self._recorder.record('emoji', {
            'time': time.strftime('%H:%M:%S'),
            'user_id': uid, 'user_name': user.nick_name,
            'emoji_id': msg.emoji_id, 'content': content,
            'grade': _fmt_grade(user), 'fans_club': _fmt_fans_club(user),
        })

    def _parseRoomMsg(self, payload):
        msg = _parse(RoomMessage, payload)
        is_top = "[置顶]" if msg.system_top_msg else ""
        detail = f"直播间id:{msg.common.room_id}"
        if msg.content:
            detail += f", 内容:{msg.content}"
        if msg.biz_scene:
            detail += f", 场景:{msg.biz_scene}"
        logger.info(f"直播间信息 - {is_top}{detail}")
        self._recorder.record('room', {
            'time': time.strftime('%H:%M:%S'),
            'is_top': '是' if msg.system_top_msg else '否',
            'room_id': msg.common.room_id if msg.common else '',
            'content': msg.content or '',
            'biz_scene': msg.biz_scene or '',
        })

    def _parseRoomStatsMsg(self, payload):
        msg = _parse(RoomStatsMessage, payload)
        detail = msg.display_long or msg.display_middle or msg.display_short or str(msg.total)
        logger.info(f"直播间统计信息 - {detail} (数值:{msg.total})")
        self._recorder.record('roomstats', {
            'time': time.strftime('%H:%M:%S'),
            'detail': detail,
            'total': msg.total,
        })

    def _parseRankMsg(self, payload):
        if not self._enable_outputs.get('rank', True):
            return
        msg = _parse(RoomRankMessage, payload)
        if not msg.ranks_list:
            return
        items = [f"{i}.{r.user.nick_name}{_fmt_fans_club(r.user)} 积分:{r.score_str}"
                 for i, r in enumerate(msg.ranks_list, 1) if r.score_str]
        if items:
            logger.info(f"排行榜消息 - {' | '.join(items)}")
            self._recorder.record('rank', {
                'time': time.strftime('%H:%M:%S'),
                'ranks': ' | '.join(items),
            })

    def _parseControlMsg(self, payload):
        msg = _parse(ControlMessage, payload)
        status = {1: "开始", 2: "暂停", 3: "已结束"}.get(msg.status, f"未知({msg.status})")
        logger.info(f"直播间状态 - {status}")
        self._recorder.record('control', {
            'time': time.strftime('%H:%M:%S'),
            'status': status,
        })
        if msg.status == 3:
            logger.warning("直播间已结束，停止采集")
            self.stop()

    def _parseRoomStreamAdaptationMsg(self, payload):
        msg = _parse(RoomStreamAdaptationMessage, payload)
        logger.info(f"流配置消息 - 类型:{msg.adaptation_type}")

    # ── 无 protobuf 定义的通用解析（用 common 字段兜底）──

    @staticmethod
    def _parse_common(payload):
        """从任意消息中提取 common 字段（room_id, msg_id 等）"""
        try:
            common = _parse(Common, payload)
            return {
                'room_id': common.room_id,
                'msg_id': common.msg_id,
                'method': common.method,
            }
        except Exception:
            return {}

    def _parseRanklistHourEntranceMsg(self, payload):
        """小时榜入口 — 频率高但价值低，仅 debug 输出"""
        logger.debug(f"小时榜入口消息")

    def _parseRoomDataSyncMsg(self, payload):
        """房间数据同步 — 频率高，仅 debug 输出"""
        logger.debug(f"房间数据同步消息")

    def _parseChatLikeMsg(self, payload):
        """聊天点赞（点击消息上的赞按钮，区别于双击点赞）"""
        logger.debug(f"聊天点赞消息")

    def _parseGenericMsg(self, payload, method):
        """通用兜底 — 记录 method 名称"""
        logger.debug(f"其他消息: {method}")


# handler 分发表
DouyinLiveWebFetcher._HANDLERS = {
    'WebcastChatMessage':                 DouyinLiveWebFetcher._parseChatMsg,
    'WebcastGiftMessage':                 DouyinLiveWebFetcher._parseGiftMsg,
    'WebcastLikeMessage':                 DouyinLiveWebFetcher._parseLikeMsg,
    'WebcastMemberMessage':               DouyinLiveWebFetcher._parseMemberMsg,
    'WebcastSocialMessage':               DouyinLiveWebFetcher._parseSocialMsg,
    'WebcastRoomUserSeqMessage':          DouyinLiveWebFetcher._parseRoomUserSeqMsg,
    'WebcastFansclubMessage':             DouyinLiveWebFetcher._parseFansclubMsg,
    'WebcastControlMessage':              DouyinLiveWebFetcher._parseControlMsg,
    'WebcastEmojiChatMessage':            DouyinLiveWebFetcher._parseEmojiChatMsg,
    'WebcastRoomStatsMessage':            DouyinLiveWebFetcher._parseRoomStatsMsg,
    'WebcastRoomMessage':                 DouyinLiveWebFetcher._parseRoomMsg,
    'WebcastRoomRankMessage':             DouyinLiveWebFetcher._parseRankMsg,
    'WebcastRoomStreamAdaptationMessage': DouyinLiveWebFetcher._parseRoomStreamAdaptationMsg,
}
