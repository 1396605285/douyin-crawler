#!/usr/bin/python
# coding:utf-8

# @FileName:    main.py
# @Time:        2024/1/2 22:27
# @Author:      bubu
# @Project:     douyinLiveWebFetcher
# @Description: 抖音直播间弹幕数据采集器 - 启动入口

import os
import signal
import sys
from liveMan import DouyinLiveWebFetcher

room = None


def signal_handler(signum, frame):
    """信号处理函数，优雅退出"""
    print("\n【收到停止信号，正在优雅退出...】")
    if room:
        room.stop()
    sys.exit(0)


if __name__ == '__main__':
    # 切换到脚本所在目录
    script_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(script_dir)
    sys.path.insert(0, script_dir)

    # 注册信号处理
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)

    # 配置直播间 ID
    live_id = '536863152858'

    print("=" * 60)
    print("抖音直播间弹幕数据采集器 (优化版)")
    print("=" * 60)
    print(f"直播间 ID: {live_id}")
    print(f"日志文件: douyin_live.log")
    print(f"配置文件: config.json")
    print("=" * 60)
    print("按 Ctrl+C 停止采集\n")

    # 创建采集器实例
    room = DouyinLiveWebFetcher(live_id, config_file='config.json')

    # 启动采集
    try:
        room.start()
    except KeyboardInterrupt:
        print("\n【用户中断，停止采集】")
        room.stop()
    except Exception as e:
        print(f"\n【采集失败: {e}】")
        room.stop()
        sys.exit(1)
