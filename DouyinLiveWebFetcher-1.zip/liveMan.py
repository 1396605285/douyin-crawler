#!/usr/bin/python
# coding:utf-8

# @FileName:    liveMan.py
# @Time:        2024/1/2 21:51
# @Author:      bubu
# @Project:     douyinLiveWebFetcher
# @Description: 抖音直播间弹幕数据采集器 - 稳定、持续、快速、高效、完整采集

import codecs
import gzip
import hashlib
import json
import logging
import os
import random
import re
import string
import threading
import time
import urllib.parse

import execjs
import requests
import websocket

from ac_signature import get__ac_signature
from protobuf.douyin import *

from urllib3.util.url import parse_url

# 配置日志系统
_log_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'douyin_live.log')
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler(_log_file, encoding='utf-8')
    ]
)
logger = logging.getLogger(__name__)


def execute_js(js_file: str):
    """
    执行 JavaScript 文件
    :param js_file: JavaScript 文件路径
    :return: 执行结果
    """
    js_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), js_file)
    with open(js_file_path, 'r', encoding='utf-8') as file:
        js_code = file.read()
    
    ctx = execjs.compile(js_code)
    return ctx


def generateSignature(wss, script_file='sign.js'):
    """
    生成 WebSocket 签名
    :param wss: WebSocket URL
    :param script_file: 签名脚本文件名
    :return: 签名字符串
    """
    params = ("live_id,aid,version_code,webcast_sdk_version,"
              "room_id,sub_room_id,sub_channel_id,did_rule,"
              "user_unique_id,device_platform,device_type,ac,"
              "identity").split(',')
    wss_params = urllib.parse.urlparse(wss).query.split('&')
    wss_maps = {i.split('=')[0]: i.split("=")[-1] for i in wss_params}
    tpl_params = [f"{i}={wss_maps.get(i, '')}" for i in params]
    param = ','.join(tpl_params)
    md5 = hashlib.md5()
    md5.update(param.encode())
    md5_param = md5.hexdigest()
    
    script_file_path = os.path.join(os.path.dirname(os.path.abspath(__file__)), script_file)
    with codecs.open(script_file_path, 'r', encoding='utf8') as f:
        script = f.read()
    
    try:
        context = execjs.compile(script)
        signature = context.call("get_sign", md5_param)
        logger.debug(f"生成签名成功: {signature}")
        return signature
    except Exception as e:
        logger.error(f"生成签名失败: {e}")
        raise


def generateMsToken(length=182):
    """
    生成随机 msToken
    :param length: 长度
    :return: msToken 字符串
    """
    random_str = ''
    base_str = string.ascii_letters + string.digits + '-_'
    _len = len(base_str) - 1
    for _ in range(length):
        random_str += base_str[random.randint(0, _len)]
    return random_str


class DouyinLiveWebFetcher:
    """
    抖音直播间弹幕数据采集器
    特性：稳定、持续、快速、高效、完整采集
    """
    
    def __init__(self, live_id, abogus_file='a_bogus.js', config_file='config.json'):
        """
        初始化直播间弹幕采集器
        :param live_id: 直播间 ID
        :param abogus_file: a_bogus 签名文件路径
        :param config_file: 配置文件路径
        """
        self.abogus_file = abogus_file
        self.config = self._load_config(config_file)
        self._enable_outputs = self.config.get('output', {})
        
        # 共享 session 和连接池
        self.session = requests.Session()
        self.session.headers.update({
            'User-Agent': self._get_random_user_agent()
        })
        
        self.live_id = live_id
        self.host = "https://www.douyin.com/"
        self.live_url = "https://live.douyin.com/"
        
        # WebSocket 连接状态
        self.ws = None
        self._is_connected = False
        self._reconnect_count = 0
        self._max_reconnects = 10
        self._reconnect_delay = 1
        self._max_reconnect_delay = 60
        
        # 心跳控制
        self._heartbeat_interval = 5
        self._last_heartbeat_time = 0
        self._heartbeat_lock = threading.Lock()
        
        # 连接锁
        self._connect_lock = threading.Lock()
    
    def _get_random_user_agent(self):
        """
        获取随机 User-Agent，避免被识别为机器人
        :return: 随机 User-Agent 字符串
        """
        user_agents = [
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
            "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.1 Safari/605.1.15"
        ]
        return random.choice(user_agents)
    
    def _load_config(self, config_file):
        """
        加载配置文件
        :param config_file: 配置文件路径
        :return: 配置字典
        """
        # 将相对路径转换为基于脚本目录的绝对路径
        if not os.path.isabs(config_file):
            config_file = os.path.join(os.path.dirname(os.path.abspath(__file__)), config_file)
        try:
            with open(config_file, 'r', encoding='utf-8') as f:
                config = json.load(f)
            logger.info(f"加载配置文件成功: {config_file}")
            return config
        except FileNotFoundError:
            logger.warning(f"配置文件不存在，使用默认配置: {config_file}")
            return {'output': {}}
        except json.JSONDecodeError as e:
            logger.error(f"配置文件格式错误: {e}")
            return {'output': {}}
    
    def _get_with_retry(self, url, max_retries=3, **kwargs):
        """
        带重试机制的 HTTP 请求
        :param url: 请求 URL
        :param max_retries: 最大重试次数
        :param kwargs: 其他请求参数
        :return: 响应对象
        """
        for attempt in range(max_retries):
            try:
                logger.debug(f"HTTP 请求 (尝试 {attempt + 1}/{max_retries}): {url}")
                response = self.session.get(url, **kwargs)
                response.raise_for_status()
                return response
            except requests.RequestException as e:
                logger.warning(f"HTTP 请求失败 (尝试 {attempt + 1}/{max_retries}): {e}")
                if attempt < max_retries - 1:
                    time.sleep(2 ** attempt)  # 指数退避
                else:
                    raise
    
    def start(self):
        """
        启动直播间弹幕采集
        """
        logger.info(f"启动直播间弹幕采集: live_id={self.live_id}")
        self._connectWebSocket()
    
    def stop(self):
        """
        停止采集并关闭连接
        """
        logger.info("停止直播间弹幕采集")
        self._is_connected = False
        if self.ws:
            self.ws.close()
    
    @property
    def ttwid(self):
        """
        获取 ttwid cookie
        :return: ttwid 字符串
        """
        if hasattr(self, '_ttwid') and self._ttwid:
            return self._ttwid
        
        try:
            response = self._get_with_retry(self.live_url)
            self._ttwid = response.cookies.get('ttwid')
            logger.debug(f"获取 ttwid 成功: {self._ttwid}")
            return self._ttwid
        except Exception as e:
            logger.error(f"获取 ttwid 失败: {e}")
            raise
    
    @property
    def room_id(self):
        """
        获取直播间 ID
        :return: room_id 字符串
        """
        if hasattr(self, '_room_id') and self._room_id:
            return self._room_id
        
        url = f"{self.live_url}{self.live_id}"
        headers = {
            "User-Agent": self.session.headers['User-Agent'],
            "cookie": f"ttwid={self.ttwid}&msToken={generateMsToken()}; __ac_nonce=0123407cc00a9e438deb4",
        }
        
        try:
            response = self._get_with_retry(url, headers=headers)
            match = re.search(r'roomId\\":\\"(\d+)\\"', response.text)
            if not match or len(match.groups()) < 1:
                error_msg = f"无法找到 roomId，响应内容: {response.text[:200]}"
                logger.error(error_msg)
                raise ValueError(error_msg)
            
            self._room_id = match.group(1)
            logger.info(f"获取 room_id 成功: {self._room_id}")
            return self._room_id
        except Exception as e:
            logger.error(f"获取 room_id 失败: {e}")
            raise
    
    def get_ac_nonce(self):
        """
        获取 __ac_nonce
        :return: __ac_nonce 字符串
        """
        try:
            resp_cookies = self.session.get(self.host, headers=self.session.headers).cookies
            nonce = resp_cookies.get("__ac_nonce")
            logger.debug(f"获取 __ac_nonce 成功: {nonce}")
            return nonce
        except Exception as e:
            logger.error(f"获取 __ac_nonce 失败: {e}")
            raise
    
    def get_ac_signature(self, __ac_nonce: str = None) -> str:
        """
        获取 __ac_signature
        :param __ac_nonce: __ac_nonce 值
        :return: __ac_signature 字符串
        """
        try:
            __ac_signature = get__ac_signature(self.host[8:], __ac_nonce, self.session.headers['User-Agent'])
            self.session.cookies.set("__ac_signature", __ac_signature)
            logger.debug(f"获取 __ac_signature 成功")
            return __ac_signature
        except Exception as e:
            logger.error(f"获取 __ac_signature 失败: {e}")
            raise
    
    def get_a_bogus(self, url_params: dict):
        """
        获取 a_bogus
        :param url_params: URL 参数字典
        :return: a_bogus 字符串
        """
        url = urllib.parse.urlencode(url_params)
        ctx = execute_js(self.abogus_file)
        _a_bogus = ctx.call("get_ab", url, self.session.headers['User-Agent'])
        logger.debug(f"获取 a_bogus 成功")
        return _a_bogus
    
    def _connectWebSocket(self):
        """
        连接 WebSocket 并启动消息处理
        """
        with self._connect_lock:
            if self._is_connected:
                logger.warning("WebSocket 已连接，忽略重复连接请求")
                return
            
            logger.info("开始连接 WebSocket...")
            
            # 构建 WebSocket URL
            wss = self._buildWebSocketURL()
            
            # 生成签名
            try:
                signature = generateSignature(wss, script_file='sign.js')
            except Exception as e:
                logger.error(f"生成 WebSocket 签名失败: {e}")
                return
            
            wss += f"&signature={signature}"
            
            # 设置 WebSocket 参数
            headers = {
                "cookie": f"ttwid={self.ttwid}",
                'user-agent': self.session.headers['User-Agent'],
            }
            
            # 创建 WebSocket 连接
            self.ws = websocket.WebSocketApp(
                wss,
                header=headers,
                on_open=self._wsOnOpen,
                on_message=self._wsOnMessage,
                on_error=self._wsOnError,
                on_close=self._wsOnClose
            )
            
            # 启动 WebSocket 连接
            try:
                self.ws.run_forever()
            except Exception as e:
                logger.error(f"WebSocket 连接异常: {e}")
                self._handleReconnect()
    
    def _buildWebSocketURL(self):
        """
        构建 WebSocket URL
        :return: WebSocket URL 字符串
        """
        return ("wss://webcast100-ws-web-lq.douyin.com/webcast/im/push/v2/?app_name=douyin_web"
                "&version_code=180800&webcast_sdk_version=1.0.14-beta.0"
                "&update_version_code=1.0.14-beta.0&compress=gzip&device_platform=web&cookie_enabled=true"
                "&screen_width=1536&screen_height=864&browser_language=zh-CN&browser_platform=Win32"
                "&browser_name=Mozilla"
                "&browser_version=5.0%20(Windows%20NT%2010.0;%20Win64;%20x64)%20AppleWebKit/537.36%20(KHTML,"
                "%20like%20Gecko)%20Chrome/126.0.0.0%20Safari/537.36"
                "&browser_online=true&tz_name=Asia/Shanghai"
                f"&internal_ext=internal_src:dim|wss_push_room_id:{self.room_id}|wss_push_did:7319483754668557238"
                f"|first_req_ms:1721106114541|fetch_time:1721106114633|seq:1|wss_info:0-1721106114633-0-0|"
                f"wrds_v:7392094459690748497"
                f"&host=https://live.douyin.com&aid=6383&live_id=1&did_rule=3&endpoint=live_pc&support_wrds=1"
                f"&user_unique_id=7319483754668557238&im_path=/webcast/im/fetch/&identity=audience"
                f"&need_persist_msg_count=15&insert_task_id=&live_reason=&room_id={self.room_id}&heartbeatDuration=0")
    
    def _handleReconnect(self):
        """
        处理重连逻辑
        """
        if self._reconnect_count >= self._max_reconnects:
            logger.error(f"达到最大重连次数 ({self._max_reconnects})，停止重连")
            return
        
        self._reconnect_count += 1
        delay = min(self._reconnect_delay * (2 ** (self._reconnect_count - 1)), self._max_reconnect_delay)
        
        logger.warning(f"WebSocket 连接断开，{delay} 秒后尝试重连 ({self._reconnect_count}/{self._max_reconnects})...")
        time.sleep(delay)
        
        try:
            self._connectWebSocket()
        except Exception as e:
            logger.error(f"重连失败: {e}")
            self._handleReconnect()
    
    def _sendHeartbeat(self):
        """
        发送心跳包（使用指数退避）
        """
        while self._is_connected:
            try:
                with self._heartbeat_lock:
                    current_time = time.time()
                    time_since_last_heartbeat = current_time - self._last_heartbeat_time
                    
                    # 心跳间隔动态调整：正常情况 5 秒，网络不稳定时增加
                    interval = max(3, min(10, time_since_last_heartbeat + 2))
                    
                    if time_since_last_heartbeat >= interval:
                        heartbeat = PushFrame(payload_type='hb').SerializeToString()
                        self.ws.send(heartbeat, websocket.ABNF.OPCODE_PING)
                        self._last_heartbeat_time = current_time
                        logger.debug(f"发送心跳包 (间隔: {interval:.1f}s)")
            
            except Exception as e:
                logger.error(f"心跳包发送失败: {e}")
                time.sleep(5)
            else:
                # 心跳间隔 1-5 秒随机波动，避免固定间隔被检测
                time.sleep(random.uniform(1, 5))
    
    def _wsOnOpen(self, ws):
        """
        WebSocket 连接打开回调
        :param ws: WebSocket 实例
        """
        logger.info("WebSocket 连接成功")
        self._is_connected = True
        self._reconnect_count = 0
        self._last_heartbeat_time = time.time()
        
        # 启动心跳线程
        heartbeat_thread = threading.Thread(target=self._sendHeartbeat, daemon=True)
        heartbeat_thread.start()
    
    def _wsOnMessage(self, ws, message):
        """
        WebSocket 消息接收回调
        :param ws: WebSocket 实例
        :param message: 消息内容
        """
        try:
            package = PushFrame().parse(message)
            response = Response().parse(gzip.decompress(package.payload))
            
            # 发送 ACK 确认
            if response.need_ack:
                ack = PushFrame(
                    log_id=package.log_id,
                    payload_type='ack',
                    payload=response.internal_ext.encode('utf-8')
                ).SerializeToString()
                ws.send(ack, websocket.ABNF.OPCODE_BINARY)
            
            # 处理消息
            for msg in response.messages_list:
                method = msg.method
                handler = {
                    'WebcastChatMessage': self._parseChatMsg,
                    'WebcastGiftMessage': self._parseGiftMsg,
                    'WebcastLikeMessage': self._parseLikeMsg,
                    'WebcastMemberMessage': self._parseMemberMsg,
                    'WebcastSocialMessage': self._parseSocialMsg,
                    'WebcastRoomUserSeqMessage': self._parseRoomUserSeqMsg,
                    'WebcastFansclubMessage': self._parseFansclubMsg,
                    'WebcastControlMessage': self._parseControlMsg,
                    'WebcastEmojiChatMessage': self._parseEmojiChatMsg,
                    'WebcastRoomStatsMessage': self._parseRoomStatsMsg,
                    'WebcastRoomMessage': self._parseRoomMsg,
                    'WebcastRoomRankMessage': self._parseRankMsg,
                    'WebcastRoomStreamAdaptationMessage': self._parseRoomStreamAdaptationMsg,
                }.get(method)
                
                if handler:
                    try:
                        handler(msg.payload)
                    except Exception as e:
                        logger.error(f"处理消息失败 (method={method}): {e}")
        
        except Exception as e:
            logger.error(f"解析消息失败: {e}")
    
    def _wsOnError(self, ws, error):
        """
        WebSocket 错误回调
        :param ws: WebSocket 实例
        :param error: 错误对象
        """
        logger.error(f"WebSocket 错误: {error}")
        self._is_connected = False
    
    def _wsOnClose(self, ws, close_status_code, close_msg):
        """
        WebSocket 关闭回调
        :param ws: WebSocket 实例
        :param close_status_code: 关闭状态码
        :param close_msg: 关闭消息
        """
        logger.info(f"WebSocket 连接关闭 (状态码: {close_status_code}, 消息: {close_msg})")
        self._is_connected = False
        self._handleReconnect()
    
    @staticmethod
    def _format_fans_club(user):
        """格式化粉丝团信息"""
        try:
            club = user.fans_club.data
            if club and club.club_name:
                return f"[粉丝团:{club.club_name} Lv{club.level}]"
            elif club and club.level > 0:
                return f"[粉丝团 Lv{club.level}]"
        except (AttributeError, TypeError):
            pass
        return ''
    
    @staticmethod
    def _format_pay_grade(user):
        """格式化用户等级信息"""
        try:
            grade = user.pay_grade
            if grade and grade.level > 0:
                return f"[等级{grade.level}]"
        except (AttributeError, TypeError):
            pass
        return ''
    
    def _parseChatMsg(self, payload):
        """
        解析聊天消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('chat', True):
            return
        
        try:
            message = ChatMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str if user.id_str else str(user.id)
            content = message.content
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            msg_time = message.common.create_time if message.common else 0
            time_str = time.strftime('%H:%M:%S', time.localtime(msg_time)) if (msg_time and 0 < msg_time < 4102444800) else ''
            time_info = f"[{time_str}]" if time_str else ''
            
            extras = []
            if message.visible_to_sender:
                extras.append("仅自己可见")
            if message.priority_level > 0:
                extras.append(f"优先级:{message.priority_level}")
            
            extra_str = f" ({', '.join(extras)})" if extras else ''
            
            logger.info(f"聊天消息 - 用户:{user_name}[{user_id}] 内容:{content}{extra_str}")
        
        except Exception as e:
            logger.error(f"解析聊天消息失败: {e}")
    
    def _parseGiftMsg(self, payload):
        """
        解析礼物消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('gift', True):
            return
        
        try:
            message = GiftMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str if user.id_str else str(user.id)
            gift = message.gift
            gift_name = gift.name
            gift_id = gift.id
            diamond_count = gift.diamond_count
            gift_describe = gift.describe
            gift_type = gift.type
            gift_combo = gift.combo
            gift_cnt = message.combo_count
            total_count = message.total_count
            repeat_count = message.repeat_count
            group_count = message.group_count
            fan_ticket_count = message.fan_ticket_count
            send_type = message.send_type
            send_time = message.send_time
            to_user = message.to_user
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            display_cnt = gift_cnt or total_count or repeat_count or 1
            diamond_total = diamond_count * display_cnt
            diamond_info = f" (≈{diamond_total}抖币)" if diamond_count > 0 else ""
            fan_ticket_info = f" [灯牌{fan_ticket_count}]" if fan_ticket_count > 0 else ""
            
            send_type_map = {1: "", 2: "[连击]", 3: "[粉丝团]"}
            send_type_info = send_type_map.get(send_type, "")
            
            extras = []
            if gift_describe:
                extras.append(f"描述:{gift_describe}")
            if gift_type > 0:
                extras.append(f"类型:{gift_type}")
            if gift_combo:
                extras.append("支持连击")
            if group_count > 1:
                extras.append(f"分组:{group_count}")
            if to_user and to_user.nick_name:
                extras.append(f"→{to_user.nick_name}")
            if send_time > 0:
                if 0 < send_time < 4102444800:
                    extras.append(f"时间:{time.strftime('%H:%M:%S', time.localtime(send_time))}")
            
            extra_str = f" ({', '.join(extras)})" if extras else ''
            
            logger.info(f"礼物消息 - 用户:{user_name}[{user_id}] 礼物:{gift_name} x{display_cnt}{diamond_info}{fan_ticket_info}{send_type_info}{extra_str}")
        
        except Exception as e:
            logger.error(f"解析礼物消息失败: {e}")
    
    def _parseLikeMsg(self, payload):
        """
        解析点赞消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('like', True):
            return
        
        try:
            message = LikeMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str if user.id_str else str(user.id)
            count = message.count
            total = message.total
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            total_info = f", 累计{total}赞" if total > 0 else ""
            
            extras = []
            if message.double_like_detail and message.double_like_detail.double_flag:
                extras.append("双击")
            if message.scene:
                extras.append(f"场景:{message.scene}")
            
            extra_str = f" ({', '.join(extras)})" if extras else ''
            
            logger.info(f"点赞消息 - 用户:{user_name}[{user_id}] 点赞:{count}个{total_info}{extra_str}")
        
        except Exception as e:
            logger.error(f"解析点赞消息失败: {e}")
    
    def _parseMemberMsg(self, payload):
        """
        解析进场消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('member', True):
            return
        
        try:
            message = MemberMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str or str(user.id)
            gender_map = {0: "未知", 1: "男", 2: "女"}
            gender = gender_map.get(user.gender, "未知")
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            top_user_info = f"[榜{message.top_user_no}]" if message.top_user_no else ""
            enter_type_info = "[回访]" if message.action and message.action != 1 else ""
            
            extras = []
            if message.member_count > 0:
                extras.append(f"直播间人数:{message.member_count}")
            if message.is_set_to_admin:
                extras.append("设为管理员")
            if message.user_enter_tip_type > 0:
                extras.append(f"进场提示类型:{message.user_enter_tip_type}")
            
            extra_str = f" ({', '.join(extras)})" if extras else ''
            
            logger.info(f"进场消息 - 用户:{user_name}[{user_id}][{gender}]{fans_club}{grade}{top_user_info}{enter_type_info} 进入了直播间{extra_str}")
        
        except Exception as e:
            logger.error(f"解析进场消息失败: {e}")
    
    def _parseSocialMsg(self, payload):
        """
        解析关注/分享消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('social', True):
            return
        
        try:
            message = SocialMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str or str(user.id)
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            action_map = {1: "关注了主播", 2: "分享了直播间"}
            action_text = action_map.get(message.action, "互动")
            follow_count_info = f"(第{message.follow_count}个关注)" if message.follow_count else ""
            share_target = f"→{message.share_target}" if message.share_target else ""
            share_type_info = f" [分享类型:{message.share_type}]" if message.share_type and message.action == 2 else ""
            
            logger.info(f"关注/分享消息 - 用户:{user_name}[{user_id}]{fans_club}{grade} {action_text}{share_target}{follow_count_info}{share_type_info}")
        
        except Exception as e:
            logger.error(f"解析关注/分享消息失败: {e}")
    
    def _parseRoomUserSeqMsg(self, payload):
        """
        解析直播间统计消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('stats', True):
            return
        
        try:
            message = RoomUserSeqMessage().parse(payload)
            current = message.total
            total = message.total_pv_for_anchor
            online_for_anchor = message.online_user_for_anchor
            total_user = message.total_user
            total_user_str = message.total_user_str
            total_str = message.total_str
            up_right = message.up_right_stats_str
            popularity = message.popularity
            
            detail = f"当前: {current}"
            if total:
                detail += f", 累计: {total}"
            if total_user_str:
                detail += f", 累计用户: {total_user_str}"
            if online_for_anchor:
                detail += f", 主播端在线: {online_for_anchor}"
            if popularity:
                detail += f", 人气值: {popularity}"
            if up_right:
                detail += f", 右上角: {up_right}"
            
            logger.info(f"统计消息 - {detail}")
        
        except Exception as e:
            logger.error(f"解析统计消息失败: {e}")
    
    def _parseFansclubMsg(self, payload):
        """
        解析粉丝团消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('fansclub', True):
            return
        
        try:
            message = FansclubMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str or str(user.id)
            content = message.content
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            type_map = {1: "升级", 2: "加入"}
            type_text = type_map.get(message.type, "变动")
            
            logger.info(f"粉丝团消息 - 用户:{user_name}[{user_id}]{fans_club}{grade} {type_text}: {content}")
        
        except Exception as e:
            logger.error(f"解析粉丝团消息失败: {e}")
    
    def _parseEmojiChatMsg(self, payload):
        """
        解析表情消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('emoji', True):
            return
        
        try:
            message = EmojiChatMessage().parse(payload)
            user = message.user
            user_name = user.nick_name
            user_id = user.id_str or str(user.id)
            emoji_id = message.emoji_id
            default_content = message.default_content
            fans_club = self._format_fans_club(user)
            grade = self._format_pay_grade(user)
            
            content = default_content or f"[表情{emoji_id}]"
            
            extras = []
            if message.from_intercom:
                extras.append("对讲")
            if message.emoji_content and message.emoji_content.default_patter:
                extras.append(f"表情文本:{message.emoji_content.default_patter}")
            
            extra_str = f" ({', '.join(extras)})" if extras else ''
            
            logger.info(f"表情消息 - 用户:{user_name}[{user_id}]{fans_club}{grade}: {content}{extra_str}")
        
        except Exception as e:
            logger.error(f"解析表情消息失败: {e}")
    
    def _parseRoomMsg(self, payload):
        """
        解析直播间信息消息
        :param payload: 消息负载
        """
        try:
            message = RoomMessage().parse(payload)
            common = message.common
            room_id = common.room_id
            create_time = common.create_time
            content = message.content
            msg_type = message.roommessagetype
            is_top = "[置顶]" if message.system_top_msg else ""
            
            detail = f"直播间id:{room_id}"
            if content:
                detail += f", 内容:{content}"
            if create_time and 0 < create_time < 4102444800:
                detail += f", 时间:{time.strftime('%H:%M:%S', time.localtime(create_time))}"
            if message.forced_guarantee:
                detail += ", [强制保证]"
            if message.biz_scene:
                detail += f", 场景:{message.biz_scene}"
            
            logger.info(f"直播间信息 - {is_top}{detail}")
        
        except Exception as e:
            logger.error(f"解析直播间信息失败: {e}")
    
    def _parseRoomStatsMsg(self, payload):
        """
        解析直播间统计信息消息
        :param payload: 消息负载
        """
        try:
            message = RoomStatsMessage().parse(payload)
            display_short = message.display_short
            display_middle = message.display_middle
            display_long = message.display_long
            total = message.total
            display_type = message.display_type
            is_hidden = message.is_hidden
            incremental = message.incremental
            
            detail = display_long or display_middle or display_short or str(total)
            
            extra = []
            if display_short and display_long and display_short != display_long:
                extra.append(f"短:{display_short}")
            if total:
                extra.append(f"数值:{total}")
            if display_type:
                extra.append(f"类型:{display_type}")
            if is_hidden:
                extra.append("隐藏")
            if incremental:
                extra.append("增量")
            
            extra_str = f" ({', '.join(extra)})" if extra else ''
            
            logger.info(f"直播间统计信息 - {detail}{extra_str}")
        
        except Exception as e:
            logger.error(f"解析直播间统计信息失败: {e}")
    
    def _parseRankMsg(self, payload):
        """
        解析排行榜消息
        :param payload: 消息负载
        """
        if not self._enable_outputs.get('rank', True):
            return
        
        try:
            message = RoomRankMessage().parse(payload)
            ranks_list = message.ranks_list
            if not ranks_list:
                return
            
            rank_items = []
            for i, rank in enumerate(ranks_list, 1):
                user = rank.user
                user_name = user.nick_name
                user_id = user.id_str or user.id
                score_str = rank.score_str
                hidden = "[隐身]" if rank.profile_hidden else ""
                fans_club = self._format_fans_club(user)
                grade = self._format_pay_grade(user)
                score_info = f" 积分:{score_str}" if score_str else ""
                rank_items.append(f"{i}.{user_name}{fans_club}{grade}{hidden}{score_info}")
            
            logger.info(f"排行榜消息 - {' | '.join(rank_items)}")
        
        except Exception as e:
            logger.error(f"解析排行榜消息失败: {e}")
    
    def _parseControlMsg(self, payload):
        """
        解析直播间状态消息
        :param payload: 消息负载
        """
        try:
            message = ControlMessage().parse(payload)
            status_map = {1: "开始", 2: "暂停", 3: "已结束"}
            status_text = status_map.get(message.status, f"未知({message.status})")
            
            logger.info(f"直播间状态 - {status_text}")
            
            if message.status == 3:
                logger.warning("直播间已结束，停止采集")
                self.stop()
        
        except Exception as e:
            logger.error(f"解析直播间状态失败: {e}")
    
    def _parseRoomStreamAdaptationMsg(self, payload):
        """
        解析直播间流配置消息
        :param payload: 消息负载
        """
        try:
            message = RoomStreamAdaptationMessage().parse(payload)
            adaptation_type = message.adaptation_type
            height_ratio = message.adaptation_height_ratio
            body_center_ratio = message.adaptation_body_center_ratio
            
            detail = f"类型:{adaptation_type}"
            if height_ratio:
                detail += f", 高度比:{height_ratio:.2f}"
            if body_center_ratio:
                detail += f", 中心比:{body_center_ratio:.2f}"
            
            logger.info(f"流配置消息 - {detail}")
        
        except Exception as e:
            logger.error(f"解析流配置消息失败: {e}")
