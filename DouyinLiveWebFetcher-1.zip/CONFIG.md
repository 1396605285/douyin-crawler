# 输出配置说明

配置文件：`config.json`

| 字段 | 类型 | 默认值 | 说明 |
|------|------|--------|------|
| `chat` | bool | true | 聊天消息（用户发送的文字弹幕） |
| `gift` | bool | true | 礼物消息（用户赠送礼物） |
| `like` | bool | true | 点赞消息（用户点赞） |
| `member` | bool | true | 进场消息（用户进入直播间） |
| `social` | bool | true | 关注/分享消息（用户关注或分享直播间） |
| `rank` | bool | true | 排行榜消息（直播间积分排行榜） |
| `stats` | bool | true | 统计消息（直播间在线人数、人气值等） |
| `fansclub` | bool | true | 粉丝团消息（用户加入或升级粉丝团） |
| `emoji` | bool | true | 表情消息（用户发送的表情包） |

## 示例

只输出聊天和礼物：
```json
{
  "output": {
    "chat": true,
    "gift": true,
    "like": false,
    "member": false,
    "social": false,
    "rank": false,
    "stats": false,
    "fansclub": false,
    "emoji": false
  }
}
```