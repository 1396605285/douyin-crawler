# 抖音直播间弹幕数据抓取

## 功能说明

本程序用于实时抓取抖音直播间弹幕数据，包括以下消息类型：

| 消息类型 | 说明 | 示例输出 |
|---|---|---|
| **聊天消息** | 用户发送的文字弹幕 | `【聊天msg】[2669243573218695]B海蓝天: 今天有点不一样[捂脸] (优先级:1)` |
| **进入直播间** | 新用户加入直播间 | `【进场msg】[101670515451][男][粉丝团 Lv10]陳墨白 进入了直播间 (直播间人数: 399)` |
| **点赞消息** | 用户点赞 | `【点赞msg】[111111][粉丝团 Lv10]糠*** 点了9个赞, 累计15赞 (双击)` |
| **关注消息** | 用户关注主播 | `【关注msg】[111111][粉丝团 Lv10]糠*** 关注了主播 (第1个关注)` |
| **礼物消息** | 用户赠送礼物 | `【礼物msg】[66637008694][等级5]🐷囔囔滴男盆友 送出了 粉丝团灯牌 x1 (≈100抖币) [灯牌10] [粉丝团] (描述:粉絲团灯牌)` |
| **粉丝团消息** | 用户加入/升级粉丝团 | `【粉丝团msg】[97729506904][粉丝团 Lv28]恭喜 成为粉丝团第289687名成员` |
| **表情消息** | 用户发送表情包 | `【表情msg】[58977458943]🌈烹世酌生: [表情23] (表情文本:🎉)` |
| **直播间统计** | 实时观看人数等统计 | `【统计msg】当前: 398, 累计: 8.2万, 累计用户: 8.2万, 主播端在线: 398, 人气值: 1234567, 右上角: 1.2万` |
| **排行榜** | 实时积分排行榜 | `【排行榜msg】1.[小阿七.] [粉丝团 Lv10] 积分:99999 \| 2.[桔你萝柚] [粉丝团 Lv10] 积分:88888 \| 3.[沈惞言] [粉丝团 Lv8]` |
| **直播间状态** | 直播开始/暂停/结束 | `【直播间状态msg】开始` 或 `【直播间状态msg】已结束` |
| **流配置** | 直播流适配信息 | `【流配置msg】类型:1, 高度比:0.56, 中心比:0.50` |

## 安装依赖

```bash
pip install -r requirements.txt
```

### 环境要求

- Python 3.7+
- Node.js（用于 PyExecJS 执行 JavaScript 签名脚本）

## 快速开始

```bash
# 运行主程序（使用默认直播间 ID）
python3 main.py
```

### 修改直播间 ID

编辑 `main.py`，修改 `live_id` 变量：

```python
live_id = '883630843489'  # 替换为你想抓取的直播间 ID
```

## 程序运行机制

### 1. 获取 ttwid

- 访问 `https://live.douyin.com/` 获取 `ttwid` cookie
- 用于 WebSocket 连接鉴权

### 2. 获取 roomId

- 访问 `https://live.douyin.com/{live_id}` 解析 HTML
- 从页面提取真实 `roomId`（有时与 live_id 不一致）

### 3. WebSocket 连接

- 建立 WebSocket 连接到抖音服务器
- 生成签名：`sign.js`（WebSocket URL 签名）
- 发送心跳包（每 5 秒一次）

### 4. 消息解析

接收到的消息经过以下步骤处理：

```
WebSocket 二进制数据
    ↓
PushFrame 解析（帧头）
    ↓
gzip 解压
    ↓
Response 解析（响应头）
    ↓
遍历 messages_list
    ↓
根据 method 字段分发到对应解析函数
    ↓
protobuf 反序列化
    ↓
格式化输出
```

### 5. 签名算法

#### WebSocket 签名（sign.js）

**用途**：对 WebSocket URL 进行签名，防止直接访问

**输入参数**（拼接后 MD5）：
```
live_id,aid,version_code,webcast_sdk_version,room_id,sub_room_id,sub_channel_id,did_rule,
user_unique_id,device_platform,device_type,ac,identity
```

**输出**：签名字符串

#### a_bogus 签名（a_bogus.js）

**用途**：对请求参数进行混淆，防止参数被篡改

**输入**：
- URL 参数字符串
- User-Agent

**输出**：`a_bogus` 参数值

#### ac_signature 签名（ac_signature.py）

**用途**：计算 `_ac_signature` cookie 值

**算法**：基于时间戳和随机数的哈希运算

## 弹幕数据定义

### Protobuf 消息结构

所有消息通过 protobuf 定义，使用 `betterproto` 库解析。

### 核心消息类型

#### 1. ChatMessage - 聊天消息

```protobuf
message ChatMessage {
    Common common = 1;              // 通用字段
    User user = 2;                  // 发送者信息
    string content = 3;             // 消息内容
    bool visible_to_sender = 4;     // 是否仅发送者可见
    Image background_image = 5;     // 背景图
    // ... 更多字段
    LandscapeAreaCommon landscape_area_common = 13;  // 横屏区域配置
    uint32 priority_level = 12;     // 消息优先级
}
```

**常用字段**：
- `user.nick_name` — 用户昵称
- `user.id_str` — 用户 ID（字符串形式）
- `common.create_time` — 消息时间戳（秒）
- `priority_level` — 优先级（1-3，数字越大优先级越高）

#### 2. MemberMessage - 进入直播间

```protobuf
message MemberMessage {
    Common common = 1;
    User user = 2;
    uint64 member_count = 3;        // 直播间总人数
    uint64 top_user_no = 8;         // 榜位编号
    uint64 action = 10;             // 1=首次进入, 其他=再次进入
    bool is_top_user = 6;           // 是否榜上用户
    bool is_set_to_admin = 5;       // 是否设为管理员
    uint64 user_enter_tip_type = 20; // 进场提示类型
}
```

#### 3. SocialMessage - 关注/分享

```protobuf
message SocialMessage {
    Common common = 1;
    User user = 2;
    uint64 action = 4;              // 1=关注, 2=分享
    uint64 share_type = 3;          // 分享类型
    string share_target = 5;        // 分享目标
    uint64 follow_count = 6;        // 关注数
}
```

#### 4. GiftMessage - 礼物

```protobuf
message GiftMessage {
    Common common = 1;
    GiftStruct gift = 15;           // 礼物信息
    uint64 gift_id = 2;
    uint64 diamond_count = 12;      // 抖币数量
    uint64 combo_count = 6;         // 连击数
    uint64 total_count = 29;        // 总数
    uint64 repeat_count = 5;        // 重复发送数
    uint64 send_type = 17;          // 1=普通, 2=连击, 3=粉丝团
    uint64 send_time = 33;          // 发送时间戳
    User to_user = 8;               // 接收者（送礼给主播）
    // ... 更多字段
}
```

**GiftStruct 礼物结构**：
```protobuf
message GiftStruct {
    string name = 16;               // 礼物名称
    uint64 id = 5;                  // 礼物 ID
    uint32 diamond_count = 12;      // 抖币数量
    uint32 type = 11;               // 礼物类型
    bool combo = 10;                // 是否支持连击
    string describe = 2;            // 礼物描述
}
```

#### 5. LikeMessage - 点赞

```protobuf
message LikeMessage {
    Common common = 1;
    User user = 5;
    uint64 count = 2;               // 本次点赞数
    uint64 total = 3;               // 累计点赞数
    uint64 color = 4;               // 点赞颜色
    // ... 更多字段
}
```

#### 6. FansclubMessage - 粉丝团

```protobuf
message FansclubMessage {
    CommonInfo common_info = 1;     // 注意：字段名是 common_info，不是 common
    int32 type = 2;                 // 1=升级, 2=加入
    string content = 3;             // 消息内容
    User user = 4;                  // 用户信息
}
```

#### 7. EmojiChatMessage - 表情

```protobuf
message EmojiChatMessage {
    Common common = 1;
    User user = 2;
    int64 emoji_id = 3;             // 表情 ID
    Text emoji_content = 4;         // 表情文本（含 default_patter）
    string default_content = 5;     // 默认内容
    bool from_intercom = 7;         // 是否对讲
}
```

#### 8. RoomUserSeqMessage - 统计

```protobuf
message RoomUserSeqMessage {
    Common common = 1;
    uint64 total = 3;               // 当前在线
    uint64 total_pv_for_anchor = 11; // 累计 PV
    string total_user_str = 8;      // 累计用户数（字符串格式）
    string total_str = 9;           // 累计数（字符串格式）
    string online_user_for_anchor = 10; // 主播端在线数
    uint64 popularity = 6;          // 人气值
    string up_right_stats_str = 12; // 右上角统计
    // ... 更多字段
}
```

#### 9. RoomRankMessage - 排行榜

```protobuf
message RoomRankMessage {
    Common common = 1;
    repeated RoomRankMessageRoomRank ranks_list = 2;
}

message RoomRankMessageRoomRank {
    User user = 1;
    string score_str = 2;           // 积分字符串
    bool profile_hidden = 3;        // 是否隐身
}
```

#### 10. RoomMessage - 直播间消息

```protobuf
message RoomMessage {
    Common common = 1;
    string content = 2;             // 消息内容
    RoomMsgTypeEnum roommessagetype = 4;
    bool system_top_msg = 5;        // 是否置顶
    bool forced_guarantee = 6;      // 是否强制保证
    string biz_scene = 20;          // 业务场景
}
```

#### 11. RoomStatsMessage - 直播间统计

```protobuf
message RoomStatsMessage {
    Common common = 1;
    string display_short = 2;       // 短格式显示
    string display_middle = 3;      // 中格式显示
    string display_long = 4;        // 长格式显示
    int64 total = 9;                // 总数
    int64 display_type = 10;        // 显示类型
    bool is_hidden = 8;             // 是否隐藏
    bool incremental = 7;           // 是否增量更新
}
```

#### 12. ControlMessage - 直播间状态

```protobuf
message ControlMessage {
    Common common = 1;
    int32 status = 2;               // 1=开始, 2=暂停, 3=已结束
}
```

#### 13. User - 用户信息

```protobuf
message User {
    uint64 id = 1;                  // 用户 ID
    string id_str = 1028;           // 用户 ID（字符串形式）
    string nick_name = 3;           // 昵称
    uint32 gender = 4;              // 性别：0=未知, 1=男, 2=女
    uint32 level = 6;               // 等级
    FansClub fans_club = 24;        // 粉丝团信息
    PayGrade pay_grade = 23;        // 支付等级
    // ... 更多字段
}
```

**FansClub 粉丝团**：
```protobuf
message FansClub {
    FansClubData data = 1;          // 粉丝团数据
    map<int32, FansClubData> prefer_data = 2;
}

message FansClubData {
    string club_name = 1;           // 粉丝团名称
    int32 level = 2;                // 等级
    UserBadge badge = 4;            // 徽章
    // ... 更多字段
}
```

**PayGrade 支付等级**：
```protobuf
message PayGrade {
    int64 level = 6;                // 等级
    string name = 3;                // 等级名称
    // ... 更多字段
}
```

## 注意事项

1. **签名脚本**：`sign.js` 和 `a_bogus.js` 由抖音官方前端提取，用于签名计算。程序直接调用这些脚本。
2. **PyExecJS 替代 MiniRacer**：由于 Termux 上无法编译 `mini_racer`（需要 Rust），使用 `PyExecJS` 调用 Node.js 执行 JavaScript 签名。
3. **数据隐私**：仅用于学习研究，严禁用于商业用途、爬虫业务或其他非法目的。
4. **反爬限制**：抖音对频繁请求有限制，建议适当增加请求间隔。

## License

本程序仅供学习研究使用。使用本程序所产生的一切后果由使用者自行承担。
